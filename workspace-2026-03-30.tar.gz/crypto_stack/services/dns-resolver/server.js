/**
 * Mamaduka .Crypto — DNS Resolver Service
 * Handles DNS queries for .crypto domains over UDP, TCP, DoH, DoT
 */

require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');
const dns = require('dns');
const dnsPromises = require('dns').promises;
const winston = require('winston');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.DNS_HTTP_PORT || 8053;
const UDP_DNS_PORT = process.env.DNS_PORT || 53;
const TCP_DNS_PORT = process.env.DNS_PORT || 53;
const TLS_DNS_PORT = process.env.DNS_OVER_TLS_PORT || 853;
const DOMAIN_SUFFIX = process.env.DNS_DOMAIN_SUFFIX || '.crypto';
const DEFAULT_TTL = parseInt(process.env.DNS_DEFAULT_TTL || '300');

// ============================================================
// LOGGING
// ============================================================
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: [
        new winston.transports.File({ filename: '/app/logs/dns-error.log', level: 'error' }),
        new winston.transports.File({ filename: '/app/logs/dns-combined.log' }),
        new winston.transports.Console({ format: winston.format.simple() })
    ]
});

// ============================================================
// DATABASE & CACHE
// ============================================================
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 20 });
const redis = new Redis(process.env.REDIS_URL);
redis.on('error', err => logger.error('Redis error:', err));

// ============================================================
// DNS PACKET PARSING
// ============================================================

// Parse incoming DNS wire-format query
function parseDnsQuery(buffer, offset = 0) {
    const transactionId = buffer.readUInt16BE(offset);
    const flags = buffer.readUInt16BE(offset + 2);
    const questions = buffer.readUInt16BE(offset + 4);
    offset += 12;

    const qname = [];
    let len = buffer[offset++];
    while (len !== 0) {
        if (len >= 0xc0) {
            // Compression pointer
            const ptr = ((len & 0x3f) << 8) | buffer[offset++];
            const [ptrResult] = parseDnsQuery(buffer, ptr);
            qname.push(ptrResult.join('.'));
            break;
        }
        qname.push(buffer.slice(offset, offset + len).toString());
        offset += len;
        len = buffer[offset++];
    }

    const qtype = buffer.readUInt16BE(offset);
    const qclass = buffer.readUInt16BE(offset + 2);

    return {
        transactionId,
        flags,
        questions,
        qname: qname.join('.'),
        qtype,
        qclass,
        offset
    };
}

// Build DNS response packet
function buildDnsResponse(query, answers) {
    const transactionId = query.transactionId;
    const flags = 0x8180; // Response, no error
    const questions = 1;
    const answerCount = answers.length;
    const authorityCount = 0;
    const additionalCount = 0;

    // Header = 12 bytes
    const header = Buffer.alloc(12);
    header.writeUInt16BE(transactionId, 0);
    header.writeUInt16BE(flags, 2);
    header.writeUInt16BE(questions, 4);
    header.writeUInt16BE(answerCount, 6);
    header.writeUInt16BE(authorityCount, 8);
    header.writeUInt16BE(additionalCount, 10);

    // Question section
    const qnameParts = query.qname.split('.');
    const question = Buffer.alloc(qnameParts.length * 2 + 4);
    let qOffset = 0;
    for (const part of qnameParts) {
        question.writeUInt8(part.length, qOffset++);
        question.write(part, qOffset);
        qOffset += part.length;
    }
    question.writeUInt8(0, qOffset++);
    question.writeUInt16BE(query.qtype, qOffset); qOffset += 2;
    question.writeUInt16BE(1, qOffset); // IN class

    // Answer section
    const answerBuffers = [];
    for (const answer of answers) {
        // Pointer to qname (offset 12 = start of question section)
        const pointer = Buffer.alloc(10 + answer.value.length);
        pointer.writeUInt16BE(0xc00c, 0); // Compression: points to byte 12
        pointer.writeUInt16BE(answer.type, 2);
        pointer.writeUInt16BE(1, 4); // IN class
        pointer.writeUInt32BE(answer.ttl || DEFAULT_TTL, 6);
        pointer.writeUInt16BE(answer.value.length, 10);
        answer.value.copy(pointer, 10 + 2);
        answerBuffers.push(pointer);
    }

    return Buffer.concat([header, question, ...answerBuffers]);
}

// Type name to number
const DNS_TYPE = { A: 1, AAAA: 28, CNAME: 5, TXT: 16, MX: 15, NS: 2, SRV: 33, SOA: 6, CAA: 257 };

// ============================================================
// DNS LOOKUP
// ============================================================
async function resolveDomain(domainName) {
    const normalized = domainName.endsWith(DOMAIN_SUFFIX) ? domainName : domainName + DOMAIN_SUFFIX;

    // Check cache first
    const cached = await redis.get(`dns:resolve:${normalized}`);
    if (cached) {
        logger.info(`Cache hit: ${normalized}`);
        return JSON.parse(cached);
    }

    // Check database
    const domain = await pool.query(`
        SELECT dr.*, d.owner_address, d.resolver_address
        FROM dns_records dr
        JOIN domains d ON dr.domain_id = d.id
        WHERE d.domain_name = $1 AND d.is_active = TRUE
    `, [normalized]);

    if (!domain.rows.length) {
        return null;
    }

    // Also get blockchain owner info
    const domainInfo = await pool.query(
        'SELECT * FROM domains WHERE domain_name = $1', [normalized]
    );

    const result = {
        domain: normalized,
        owner: domainInfo.rows[0]?.owner_address,
        records: domain.rows.map(r => ({
            type: r.record_type,
            name: r.record_name,
            value: r.record_value,
            ttl: r.ttl
        }))
    };

    await redis.setex(`dns:resolve:${normalized}`, DEFAULT_TTL, JSON.stringify(result));
    return result;
}

// Handle individual DNS query type
async function buildAnswers(domainName, qtype) {
    const resolved = await resolveDomain(domainName);
    if (!resolved) return [];

    const answers = [];

    if (qtype === 1 || qtype === 28 || qtype === 255) { // A, AAAA, or ANY
        const aRecord = resolved.records.find(r => r.type === 'A');
        if (aRecord) {
            answers.push({ type: 1, ttl: aRecord.ttl, value: Buffer.from(aRecord.value.split('.').map(Number)) });
        }

        const aaaaRecord = resolved.records.find(r => r.type === 'AAAA');
        if (aaaaRecord) {
            const parts = aaaaRecord.value.split(':');
            const ipv6 = Buffer.alloc(16);
            for (let i = 0; i < 8; i++) {
                ipv6.writeUInt16BE(parseInt(parts[i] || '0', 16), i * 2);
            }
            answers.push({ type: 28, ttl: aaaaRecord.ttl, value: ipv6 });
        }
    }

    if (qtype === 5 || qtype === 255) { // CNAME
        const cnameRecord = resolved.records.find(r => r.type === 'CNAME');
        if (cnameRecord) {
            const cnameBuf = Buffer.alloc(cnameRecord.value.length + 2);
            cnameBuf.writeUInt8(cnameRecord.value.length, 0);
            cnameBuf.write(cnameRecord.value, 1);
            answers.push({ type: 5, ttl: cnameRecord.ttl, value: cnameBuf });
        }
    }

    if (qtype === 16 || qtype === 255) { // TXT
        const txtRecords = resolved.records.filter(r => r.type === 'TXT');
        for (const txt of txtRecords) {
            const txtParts = txt.value.match(/.{1,255}/g) || [txt.value];
            const txtBuf = Buffer.alloc(txtParts.length * 2 + txt.value.length);
            let offset = 0;
            for (const part of txtParts) {
                txtBuf.writeUInt8(part.length, offset++);
                txtBuf.write(part, offset);
                offset += part.length;
            }
            answers.push({ type: 16, ttl: txt.ttl, value: txtBuf });
        }
    }

    if (qtype === 15 || qtype === 255) { // MX
        const mxRecords = resolved.records.filter(r => r.type === 'MX');
        for (const mx of mxRecords) {
            const mxBuf = Buffer.alloc(10 + mx.value.length);
            mxBuf.writeUInt16BE(mx.priority || 10, 0);
            const nameParts = mx.value.split('.');
            let offset = 4;
            for (const part of nameParts) {
                mxBuf.writeUInt8(part.length, offset++);
                mxBuf.write(part, offset);
                offset += part.length;
            }
            mxBuf.writeUInt8(0, offset);
            answers.push({ type: 15, ttl: mx.ttl, value: mxBuf });
        }
    }

    return answers;
}

// ============================================================
// UDP DNS SERVER
// ============================================================
const dgram = require('dgram');
const udpServer = dgram.createSocket('udp4');

udpServer.on('message', async (msg, rinfo) => {
    try {
        const query = parseDnsQuery(msg);

        // Only handle .crypto domains
        if (!query.qname.endsWith(DOMAIN_SUFFIX)) {
            // Forward to upstream DNS
            dnsPromises.resolve4(query.qname).then(answers => {
                const response = buildDnsResponse(query, answers.map(ip => ({
                    type: 1, ttl: 300, value: Buffer.from(ip.split('.').map(Number))
                })));
                udpServer.send(response, rinfo.port, rinfo.address);
            }).catch(() => {
                // NXDOMAIN
                const response = buildDnsResponse(query, []);
                udpServer.send(response, rinfo.port, rinfo.address);
            });
            return;
        }

        const answers = await buildAnswers(query.qname, query.qtype);
        const response = buildDnsResponse(query, answers);

        udpServer.send(response, rinfo.port, rinfo.address);
        logger.info(`[UDP] ${query.qname} ${query.qtype} -> ${answers.length} answers`);
    } catch (err) {
        logger.error('UDP DNS error:', err);
    }
});

udpServer.on('error', err => logger.error('UDP server error:', err));

// ============================================================
// TCP DNS SERVER
// ============================================================
const net = require('net');
const tcpServer = net.createServer(async (socket) => {
    socket.on('data', async (data) => {
        try {
            // TCP DNS: first 2 bytes = length
            const length = data.readUInt16BE(0);
            const msg = data.slice(2, 2 + length);
            const query = parseDnsQuery(msg);

            const answers = await buildAnswers(query.qname, query.qtype);
            const response = buildDnsResponse(query, answers);

            const responseWithLen = Buffer.alloc(2 + response.length);
            responseWithLen.writeUInt16BE(response.length, 0);
            response.copy(responseWithLen, 2);

            socket.write(responseWithLen);
            logger.info(`[TCP] ${query.qname} ${query.qtype} -> ${answers.length} answers`);
        } catch (err) {
            logger.error('TCP DNS error:', err);
            socket.end();
        }
    });
});

// ============================================================
// HTTP API (REST + DoH)
// ============================================================
app.use(express.json());
const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 100,
    message: { error: 'Rate limit exceeded' }
});
app.use(limiter);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'dns-resolver' }));

// REST DNS query
app.get('/resolve/:domain', async (req, res) => {
    try {
        const { domain } = req.params;
        const { type = 'A' } = req.query;
        const resolved = await resolveDomain(domain);

        if (!resolved) return res.status(404).json({ error: 'Domain not found' });
        res.json(resolved);
    } catch (err) {
        logger.error('Resolve error:', err);
        res.status(500).json({ error: 'Resolution failed' });
    }
});

// DoH endpoint (RFC 8484)
app.get('/dns-query', async (req, res) => {
    try {
        const dnsParam = req.query.dns;
        if (!dnsParam) return res.status(400).json({ error: 'Missing dns parameter' });

        const msg = Buffer.from(dnsParam, 'base64');
        const query = parseDnsQuery(msg);
        const answers = await buildAnswers(query.qname, query.qtype);
        const response = buildDnsResponse(query, answers);

        res.set({
            'Content-Type': 'application/dns-message',
            'Cache-Control': `max-age=${DEFAULT_TTL}`
        });
        res.send(response);
    } catch (err) {
        logger.error('DoH error:', err);
        res.status(500).send('Resolution failed');
    }
});

app.post('/dns-query', async (req, res) => {
    try {
        const msg = Buffer.from(req.body.dns, 'base64');
        const query = parseDnsQuery(msg);
        const answers = await buildAnswers(query.qname, query.qtype);
        const response = buildDnsResponse(query, answers);

        res.set({ 'Content-Type': 'application/dns-message' });
        res.send(response);
    } catch (err) {
        logger.error('DoH POST error:', err);
        res.status(500).send('Resolution failed');
    }
});

// ============================================================
// DNS RECORD MANAGEMENT API
// ============================================================
app.post('/api/v1/domains/:domain/records', async (req, res) => {
    try {
        const { domain } = req.params;
        const { recordType, recordName, recordValue, ttl, priority } = req.body;

        // Find domain
        const domainRow = await pool.query(
            'SELECT id FROM domains WHERE domain_name = $1', [domain.endsWith('.crypto') ? domain : domain + '.crypto']
        );

        if (!domainRow.rows[0]) return res.status(404).json({ error: 'Domain not found' });

        // Check tier limits
        const user = await pool.query('SELECT tier FROM users WHERE id = (SELECT owner_user_id FROM domains WHERE domain_name = $1)', [domain.endsWith('.crypto') ? domain : domain + '.crypto']);

        const limits = { starter: 10, professional: 50, enterprise: -1 };
        const currentCount = await pool.query(
            'SELECT COUNT(*) as cnt FROM dns_records WHERE domain_id = $1', [domainRow.rows[0].id]
        );

        if (limits[user.rows[0]?.tier] !== -1 && currentCount.rows[0].cnt >= limits[user.rows[0]?.tier]) {
            return res.status(403).json({ error: 'DNS record limit reached for your tier' });
        }

        const result = await pool.query(`
            INSERT INTO dns_records (domain_id, record_type, record_name, record_value, ttl, priority)
            VALUES ($1, $2, $3, $4, $5, $6) RETURNING *
        `, [domainRow.rows[0].id, recordType, recordName, recordValue, ttl || DEFAULT_TTL, priority || 0]);

        // Invalidate cache
        await redis.del(`dns:resolve:${domain}`);

        logger.info(`Record added: ${recordName} ${recordType} for ${domain}`);
        res.json(result.rows[0]);
    } catch (err) {
        logger.error('Record creation error:', err);
        res.status(500).json({ error: 'Failed to create record' });
    }
});

app.get('/api/v1/domains/:domain/records', async (req, res) => {
    try {
        const { domain } = req.params;
        const domainRow = await pool.query(
            'SELECT id FROM domains WHERE domain_name = $1', [domain.endsWith('.crypto') ? domain : domain + '.crypto']
        );

        if (!domainRow.rows[0]) return res.status(404).json({ error: 'Domain not found' });

        const records = await pool.query(
            'SELECT * FROM dns_records WHERE domain_id = $1 ORDER BY record_type', [domainRow.rows[0].id]
        );
        res.json(records.rows);
    } catch (err) {
        logger.error('Records fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch records' });
    }
});

app.delete('/api/v1/records/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const record = await pool.query('SELECT domain_id FROM dns_records WHERE id = $1', [id]);
        if (!record.rows[0]) return res.status(404).json({ error: 'Record not found' });

        await pool.query('DELETE FROM dns_records WHERE id = $1', [id]);
        logger.info(`Record deleted: ${id}`);
        res.json({ success: true });
    } catch (err) {
        logger.error('Record delete error:', err);
        res.status(500).json({ error: 'Failed to delete record' });
    }
});

// Metrics
app.get('/metrics', async (req, res) => {
    const stats = await pool.query(`
        SELECT COUNT(*) as total_records,
               COUNT(DISTINCT domain_id) as domains_with_records
        FROM dns_records
    `);
    res.json(stats.rows[0]);
});

// ============================================================
// STARTUP
// ============================================================
async function start() {
    logger.info('Starting DNS Resolver...');

    // Start UDP DNS server
    udpServer.bind(UDP_DNS_PORT, '0.0.0.0', () => {
        logger.info(`UDP DNS server listening on 0.0.0.0:${UDP_DNS_PORT}`);
    });

    // Start TCP DNS server
    tcpServer.listen(TCP_DNS_PORT, '0.0.0.0', () => {
        logger.info(`TCP DNS server listening on 0.0.0.0:${TCP_DNS_PORT}`);
    });

    // Start HTTP API
    app.listen(PORT, '0.0.0.0', () => {
        logger.info(`DNS HTTP API listening on 0.0.0.0:${PORT}`);
    });

    logger.info(`Domain suffix: ${DOMAIN_SUFFIX}`);
}

start().catch(err => {
    logger.error('DNS startup failed:', err);
    process.exit(1);
});
