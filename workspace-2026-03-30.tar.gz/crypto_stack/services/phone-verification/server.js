/**
 * Mamaduka .Crypto — Phone Verification Service
 * Handles SMS verification via Twilio for user registration
 */

require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');
const twilio = require('twilio');
const winston = require('winston');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PHONE_VERIFY_PORT || 3004;

// ============================================================
// LOGGING
// ============================================================
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: [
        new winston.transports.File({ filename: '/app/logs/phone-error.log', level: 'error' }),
        new winston.transports.File({ filename: '/app/logs/phone-combined.log' }),
        new winston.transports.Console({ format: winston.format.simple() })
    ]
});

// ============================================================
// DATABASE & CACHE
// ============================================================
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 20 });
const redis = new Redis(process.env.REDIS_URL);
redis.on('error', err => logger.error('Redis error:', err));

// ============================================================
// TWILIO CLIENT
// ============================================================
let twilioClient;
try {
    if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
        twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        logger.info('Twilio client initialized');
    } else {
        logger.warn('Twilio credentials not configured — SMS sending disabled');
    }
} catch (err) {
    logger.error('Failed to init Twilio:', err.message);
}

// ============================================================
// HELPERS
// ============================================================

// Generate 6-digit verification code
function generateCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Normalize Kenyan phone number
function normalizePhone(phone) {
    let cleaned = phone.replace(/[^\d+]/g, '');
    if (cleaned.startsWith('0')) cleaned = '+254' + cleaned.slice(1);
    else if (cleaned.startsWith('254')) cleaned = '+' + cleaned;
    else if (!cleaned.startsWith('+')) cleaned = '+254' + cleaned;
    return cleaned.replace(/^\+2540/, '+2547');
}

// Check if phone is valid Kenyan number
function isValidKenyanPhone(phone) {
    const normalized = normalizePhone(phone);
    return /^\+254[7][0-9]{8}$/.test(normalized);
}

// ============================================================
// MIDDLEWARE
// ============================================================
app.use(express.json());

const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10, // strict: only 10 SMS per minute
    message: { error: 'Too many requests, please try again later' }
});

// ============================================================
// API ROUTES
// ============================================================

app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'phone-verification' });
});

// ============================================================
// SEND VERIFICATION CODE
// POST /api/v1/verify/send
// ============================================================
app.post('/api/v1/verify/send', apiLimiter, async (req, res) => {
    const { phone, userId, purpose = 'registration' } = req.body;

    if (!phone) {
        return res.status(400).json({ error: 'Phone number is required' });
    }

    const normalizedPhone = normalizePhone(phone);

    if (!isValidKenyanPhone(phone)) {
        return res.status(400).json({ error: 'Invalid Kenyan phone number. Use format: 07XX XXX XXX or +2547XX XXX XXX' });
    }

    const code = generateCode();
    const ttl = parseInt(process.env.VERIFICATION_CODE_TTL || '300');

    logger.info(`Sending verification code to ${normalizedPhone} for ${purpose}`);

    try {
        // Store in Redis with TTL
        await redis.setex(`verify:${normalizedPhone}`, ttl, JSON.stringify({
            code,
            userId,
            purpose,
            attempts: 0,
            createdAt: Date.now()
        }));

        // Check if SMS is configured
        if (twilioClient) {
            await twilioClient.messages.create({
                body: `Mamaduka Crypto: Your verification code is ${code}. Valid for ${ttl / 60} minutes. Do not share this code.`,
                from: process.env.TWILIO_PHONE_NUMBER,
                to: normalizedPhone
            });

            logger.info(`SMS sent to ${normalizedPhone}`);
            res.json({
                success: true,
                message: 'Verification code sent via SMS',
                // In sandbox mode, include code for testing
                ...(process.env.M_PESA_ENV === 'sandbox' && { debug_code: code })
            });
        } else {
            // No Twilio — log code (for development)
            logger.info(`[DEV] Verification code for ${normalizedPhone}: ${code}`);
            res.json({
                success: true,
                message: 'Verification code generated (SMS not configured)',
                debug_code: code // Remove in production!
            });
        }
    } catch (err) {
        logger.error('SMS send error:', err);
        res.status(500).json({ error: 'Failed to send verification code', details: err.message });
    }
});

// ============================================================
// VERIFY CODE
// POST /api/v1/verify/check
// ============================================================
app.post('/api/v1/verify/check', async (req, res) => {
    const { phone, code } = req.body;

    if (!phone || !code) {
        return res.status(400).json({ error: 'Phone and code are required' });
    }

    const normalizedPhone = normalizePhone(phone);
    const cacheKey = `verify:${normalizedPhone}`;

    try {
        // Get stored verification data
        const stored = await redis.get(cacheKey);
        if (!stored) {
            return res.status(400).json({ error: 'No pending verification. Please request a new code.' });
        }

        const data = JSON.parse(stored);

        // Check attempts
        if (data.attempts >= 3) {
            await redis.del(cacheKey);
            return res.status(400).json({ error: 'Too many attempts. Please request a new code.' });
        }

        // Verify code
        if (data.code !== code) {
            // Increment attempts
            data.attempts += 1;
            await redis.setex(cacheKey, 300, JSON.stringify(data));
            return res.status(400).json({
                error: 'Invalid code',
                attempts_remaining: 3 - data.attempts
            });
        }

        // Success — mark user as verified and delete code
        await redis.del(cacheKey);

        if (data.userId) {
            await pool.query(`
                UPDATE users SET is_verified = TRUE,
                    verification_code = NULL,
                    verification_expires_at = NULL
                WHERE id = $1
            `, [data.userId]);

            // Store phone mapping
            await pool.query(`
                INSERT INTO phone_mappings (phone_number, normalized_number, token_id, verified, verification_method, verified_at)
                VALUES ($1, $1, NULL, TRUE, $2, NOW())
                ON CONFLICT (normalized_number) DO UPDATE SET verified = TRUE, verified_at = NOW()
            `, [normalizedPhone, data.purpose]);
        }

        logger.info(`Phone verified: ${normalizedPhone} for ${data.purpose}`);
        res.json({
            success: true,
            message: 'Phone number verified successfully',
            verified: true
        });

    } catch (err) {
        logger.error('Verification check error:', err);
        res.status(500).json({ error: 'Verification failed' });
    }
});

// ============================================================
// RESEND CODE
// POST /api/v1/verify/resend
// ============================================================
app.post('/api/v1/verify/resend', apiLimiter, async (req, res) => {
    const { phone } = req.body;

    if (!phone) {
        return res.status(400).json({ error: 'Phone is required' });
    }

    // Delete existing code first
    const cacheKey = `verify:${normalizePhone(phone)}`;
    await redis.del(cacheKey);

    // Forward to send endpoint
    req.body.userId = null; // Don't update userId on resend
    return app._router.handle(req, res);
});

// ============================================================
// CHECK VERIFICATION STATUS
// GET /api/v1/verify/status/:phone
// ============================================================
app.get('/api/v1/verify/status/:phone', async (req, res) => {
    const { phone } = req.params;
    const normalizedPhone = normalizePhone(phone);

    try {
        const cached = await redis.get(`verify:${normalizedPhone}`);
        if (cached) {
            return res.json({
                verified: false,
                pending: true,
                attempts_remaining: 3 - JSON.parse(cached).attempts
            });
        }

        const result = await pool.query(
            'SELECT is_verified FROM users WHERE normalized_phone = $1', [normalizedPhone]
        );

        res.json({
            verified: result.rows[0]?.is_verified || false,
            pending: false
        });
    } catch (err) {
        logger.error('Status check error:', err);
        res.status(500).json({ error: 'Failed to check status' });
    }
});

// ============================================================
// USER REGISTRATION
// POST /api/v1/users/register
// ============================================================
app.post('/api/v1/users/register', async (req, res) => {
    const { phone, fullName, email, referralCode } = req.body;

    if (!phone || !fullName) {
        return res.status(400).json({ error: 'Phone and full name are required' });
    }

    const normalizedPhone = normalizePhone(phone);

    try {
        // Check if user exists
        const existing = await pool.query(
            'SELECT id, is_verified FROM users WHERE normalized_phone = $1', [normalizedPhone]
        );

        if (existing.rows.length > 0) {
            if (!existing.rows[0].is_verified) {
                return res.status(400).json({ error: 'Phone number registered but not verified. Please verify first.' });
            }
            return res.status(400).json({ error: 'Phone number already registered' });
        }

        // Get referrer if code provided
        let referrerId = null;
        if (referralCode) {
            const referrer = await pool.query(
                'SELECT id FROM users WHERE referral_code = $1', [referralCode]
            );
            if (referrer.rows[0]) {
                referrerId = referrer.rows[0].id;
            }
        }

        // Generate unique referral code for new user
        const newReferralCode = await generateUserReferralCode();

        // Create unverified user
        const result = await pool.query(`
            INSERT INTO users (phone_number, normalized_phone, full_name, email, referral_code, referred_by, tier, is_verified)
            VALUES ($1, $2, $3, $4, $5, $6, 'starter', FALSE)
            RETURNING id, phone_number, full_name, tier, referral_code
        `, [phone, normalizedPhone, fullName, email || null, newReferralCode, referrerId]);

        const newUser = result.rows[0];

        // Create referral record if referrer exists
        if (referrerId) {
            await pool.query(`
                INSERT INTO referrals (referrer_id, referred_user_id)
                VALUES ($1, $2)
            `, [referrerId, newUser.id]);
        }

        logger.info(`New user registered: ${normalizedPhone} via referral ${referralCode || 'none'}`);

        res.json({
            success: true,
            user: {
                id: newUser.id,
                phone: newUser.phone_number,
                name: newUser.full_name,
                tier: newUser.tier,
                referral_code: newUser.referral_code
            },
            message: 'Registration successful. Please verify your phone number.'
        });

    } catch (err) {
        logger.error('Registration error:', err);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// ============================================================
// USER LOGIN (phone-based)
// POST /api/v1/users/login
// ============================================================
app.post('/api/v1/users/login', async (req, res) => {
    const { phone } = req.body;

    if (!phone) {
        return res.status(400).json({ error: 'Phone is required' });
    }

    const normalizedPhone = normalizePhone(phone);

    try {
        const user = await pool.query(
            'SELECT id, phone_number, full_name, tier, is_verified, referral_code FROM users WHERE normalized_phone = $1',
            [normalizedPhone]
        );

        if (!user.rows[0]) {
            return res.status(404).json({ error: 'Phone number not registered' });
        }

        if (!user.rows[0].is_verified) {
            return res.status(400).json({ error: 'Please verify your phone number first' });
        }

        // Update last login
        await pool.query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.rows[0].id]);

        logger.info(`User login: ${normalizedPhone}`);

        res.json({
            success: true,
            user: user.rows[0]
        });

    } catch (err) {
        logger.error('Login error:', err);
        res.status(500).json({ error: 'Login failed' });
    }
});

// ============================================================
// GENERATE REFERRAL CODE
// ============================================================
async function generateUserReferralCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code;
    let attempts = 0;

    do {
        code = '';
        const bytes = crypto.randomBytes(8);
        for (let i = 0; i < 8; i++) {
            code += chars[bytes[i] % chars.length];
        }
        const exists = await pool.query('SELECT 1 FROM users WHERE referral_code = $1', [code]);
        if (!exists.rows.length) break;
        attempts++;
    } while (attempts < 10);

    return code;
}

// ============================================================
// METRICS
// ============================================================
app.get('/metrics', async (req, res) => {
    try {
        const stats = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE is_verified = TRUE) as verified_users,
                COUNT(*) FILTER (WHERE is_verified = FALSE) as unverified_users,
                COUNT(*) as total_users
            FROM users
        `);
        res.json(stats.rows[0]);
    } catch (err) {
        logger.error('Metrics error:', err);
        res.status(500).json({ error: 'Metrics failed' });
    }
});

// ============================================================
// ERROR HANDLER
// ============================================================
app.use((err, req, res, next) => {
    logger.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// ============================================================
// START
// ============================================================
app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Phone Verification service listening on port ${PORT}`);
});
