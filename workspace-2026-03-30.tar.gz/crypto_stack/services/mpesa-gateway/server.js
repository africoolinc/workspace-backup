/**
 * Mamaduka .Crypto — M-PESA Gateway Service
 * Handles STK Push payments via Safaricom Daraja API
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { Pool } = require('pg');
const Redis = require('ioredis');
const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const winston = require('winston');

const app = express();
const PORT = process.env.MPESA_PORT || 3002;

// ============================================================
// LOGGING
// ============================================================
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: '/app/logs/mpesa-error.log', level: 'error' }),
        new winston.transports.File({ filename: '/app/logs/mpesa-combined.log' }),
        new winston.transports.Console({ format: winston.format.simple() })
    ]
});

// ============================================================
// DATABASE & CACHE
// ============================================================
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 20,
    idleTimeoutMillis: 30000
});

const redis = new Redis(process.env.REDIS_URL);
redis.on('error', err => logger.error('Redis error:', err));

// ============================================================
// M-PESA DARAJA API
// ============================================================
const MPESA_SHORTCODE = process.env.MPESA_SHORTCODE;
const MPESA_PASSKEY = process.env.MPESA_PASSKEY;
const MPESA_CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY;
const MPESA_CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET;
const MPESA_CALLBACK_URL = process.env.MPESA_CALLBACK_URL;
const ENVIRONMENT = process.env.M_PESA_ENV || 'sandbox';

const MPESA_BASE_URL = ENVIRONMENT === 'sandbox'
    ? 'https://sandbox.safaricom.co.ke'
    : 'https://api.safaricom.com';

// ============================================================
// HELPERS
// ============================================================

// Get OAuth token for M-PESA API
async function getMpesaToken() {
    const cached = await redis.get('mpesa:token');
    if (cached) return JSON.parse(cached);

    const auth = Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString('base64');
    const response = await axios.get(`${MPESA_BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
        headers: { Authorization: `Basic ${auth}` }
    });

    const token = response.data.access_token;
    await redis.setex('mpesa:token', 3000, JSON.stringify(token)); // cache 50 mins
    return token;
}

// Generate M-PESA password (for STK Push)
function generateMpesaPassword(shortcode, passkey, timestamp) {
    return Buffer.from(`${shortcode}${passkey}${timestamp}`).toString('base64');
}

// Normalize Kenyan phone number
function normalizePhone(phone) {
    let cleaned = phone.replace(/[^\d+]/g, '');
    if (cleaned.startsWith('0')) cleaned = '+254' + cleaned.slice(1);
    else if (cleaned.startsWith('254')) cleaned = '+' + cleaned;
    else if (!cleaned.startsWith('+')) cleaned = '+254' + cleaned;
    return cleaned.replace(/^\+2540/, '+2547');
}

// Generate unique checkout request ID
function generateCheckoutId() {
    return 'ws_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// ============================================================
// API ROUTES
// ============================================================
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'mpesa-gateway', timestamp: new Date().toISOString() });
});

// Metrics
app.get('/metrics', async (req, res) => {
    const stats = await pool.query(`
        SELECT status, COUNT(*) as count, SUM(amount) as total
        FROM payments WHERE created_at > NOW() - INTERVAL '24 hours'
        GROUP BY status
    `);
    res.json(stats.rows);
});

// ============================================================
// STK PUSH — Initiate payment
// ============================================================
app.post('/api/v1/payment/stk', async (req, res) => {
    const { phone, amount, domainName, tier, userId } = req.body;

    if (!phone || !amount || !tier) {
        return res.status(400).json({ error: 'phone, amount, and tier are required' });
    }

    const normalizedPhone = normalizePhone(phone);
    const checkoutId = generateCheckoutId();
    const timestamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
    const password = generateMpesaPassword(MPESA_SHORTCODE, MPESA_PASSKEY, timestamp);

    logger.info(`Initiating STK Push: ${checkoutId} | ${normalizedPhone} | KES ${amount} | ${domainName}`);

    try {
        const token = await getMpesaToken();

        const payload = {
            BusinessShortCode: MPESA_SHORTCODE,
            Password: password,
            Timestamp: timestamp,
            TransactionType: 'CustomerPayBillOnline',
            Amount: Math.floor(amount),
            PartyA: normalizedPhone,
            PartyB: MPESA_SHORTCODE,
            PhoneNumber: normalizedPhone,
            CallBackURL: MPESA_CALLBACK_URL,
            AccountReference: domainName || 'MAMADUKA_CRYPTO',
            TransactionDesc: `Crypto domain registration: ${domainName || tier} plan`
        };

        const response = await axios.post(
            `${MPESA_BASE_URL}/mpesa/stkpush/v1/processrequest`,
            payload,
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const { CheckoutRequestID, ResponseCode, ResponseDescription, CustomerMessage } = response.data;

        if (ResponseCode === '0') {
            // Record pending payment in DB
            await pool.query(`
                INSERT INTO payments (checkout_request_id, user_id, phone_number, amount, domain_name, tier, status, payment_type)
                VALUES ($1, $2, $3, $4, $5, $6, 'pending', 'stk_push')
            `, [CheckoutRequestID, userId, normalizedPhone, amount, domainName, tier]);

            // Cache checkout ID for quick lookup
            await redis.setex(`mpesa:checkout:${CheckoutRequestID}`, 600, JSON.stringify({
                phone: normalizedPhone, amount, domainName, tier, userId
            }));

            logger.info(`STK Push initiated: ${CheckoutRequestID}`);
            res.json({
                success: true,
                checkoutId: CheckoutRequestID,
                message: CustomerMessage || ResponseDescription
            });
        } else {
            logger.error(`STK Push failed: ${ResponseDescription}`);
            res.status(400).json({ error: ResponseDescription });
        }
    } catch (err) {
        logger.error('STK Push error:', err.response?.data || err.message);
        res.status(500).json({ error: 'Payment initiation failed', details: err.response?.data?.errorMessage });
    }
});

// ============================================================
// CALLBACK — M-PESA confirms payment (called by Safaricom)
// ============================================================
app.post('/api/vpesa/callback', async (req, res) => {
    const { Body } = req.body;
    const resultCode = Body?.stkCallback?.ResultCode;
    const checkoutId = Body?.stkCallback?.CheckoutRequestID;
    const items = Body?.stkCallback?.CallbackMetadata?.Item || [];

    logger.info(`M-PESA Callback: ${checkoutId} | ResultCode: ${resultCode}`);

    res.json({ ResultCode: 0, ResultDesc: 'Accepted' }); // Respond quickly to Safaricom

    try {
        if (resultCode === 0) {
            // Payment successful
            const data = {};
            for (const item of items) {
                if (item.Name === 'Amount') data.amount = parseFloat(item.Value);
                if (item.Name === 'MpesaReceiptNumber') data.receipt = item.Value;
                if (item.Name === 'TransactionDate') data.txDate = item.Value;
                if (item.Name === 'PhoneNumber') data.phone = '+' + item.Value;
            }

            // Update payment record
            const txDate = new Date(String(data.txDate));
            await pool.query(`
                UPDATE payments SET
                    status = 'completed',
                    transaction_id = $1,
                    receipt_number = $1,
                    amount = COALESCE($2, amount),
                    transaction_date = $3,
                    result_code = '0',
                    result_desc = 'Payment successful',
                    processed_at = NOW()
                WHERE checkout_request_id = $4
            `, [data.receipt, data.amount, txDate, checkoutId]);

            // Get payment details
            const payment = await pool.query(
                'SELECT * FROM payments WHERE checkout_request_id = $1', [checkoutId]
            ).then(r => r.rows[0]);

            if (payment && payment.user_id) {
                // Update user tier and total spent
                await pool.query(`
                    UPDATE users SET
                        total_spent = total_spent + $1,
                        tier = CASE
                            WHEN total_spent + $1 >= 15000 THEN 'enterprise'
                            WHEN total_spent + $1 >= 3500 THEN 'professional'
                            ELSE tier
                        END
                    WHERE id = $2
                `, [data.amount, payment.user_id]);

                // Claim referral reward if applicable
                await pool.query(`
                    UPDATE referrals SET reward_claimed = TRUE
                    WHERE referred_user_id = $1 AND payment_id IS NULL
                `, [payment.user_id]);

                logger.info(`Payment completed: ${data.receipt} | KES ${data.amount} | User: ${payment.user_id}`);
            }

            // Clear cache
            await redis.del(`mpesa:checkout:${checkoutId}`);

        } else {
            // Payment failed
            await pool.query(`
                UPDATE payments SET
                    status = 'failed',
                    result_code = $1,
                    result_desc = $2,
                    processed_at = NOW()
                WHERE checkout_request_id = $3
            `, [resultCode, Body?.stkCallback?.ResultDesc, checkoutId]);

            await redis.del(`mpesa:checkout:${checkoutId}`);
            logger.warn(`Payment failed: ${checkoutId} | ${Body?.stkCallback?.ResultDesc}`);
        }
    } catch (err) {
        logger.error('Callback processing error:', err);
    }
});

// ============================================================
// QUERY STATUS — Check if payment completed
// ============================================================
app.get('/api/v1/payment/status/:checkoutId', async (req, res) => {
    const { checkoutId } = req.params;

    try {
        // Check DB first
        const result = await pool.query(
            'SELECT * FROM payments WHERE checkout_request_id = $1', [checkoutId]
        );

        if (result.rows[0]) {
            return res.json({
                status: result.rows[0].status,
                receipt: result.rows[0].receipt_number,
                amount: result.rows[0].amount,
                message: result.rows[0].result_desc
            });
        }

        // Fallback: query M-PESA directly
        const token = await getMpesaToken();
        const timestamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
        const password = generateMpesaPassword(MPESA_SHORTCODE, MPESA_PASSKEY, timestamp);

        const response = await axios.post(
            `${MPESA_BASE_URL}/mpesa/stkpushquery/v1/query`,
            {
                BusinessShortCode: MPESA_SHORTCODE,
                Password: password,
                Timestamp: timestamp,
                CheckoutRequestID: checkoutId
            },
            { headers: { Authorization: `Bearer ${token}` } }
        );

        res.json({
            status: response.data.ResultCode === '0' ? 'completed' : 'pending',
            message: response.data.ResultDesc
        });
    } catch (err) {
        logger.error('Payment status error:', err.response?.data || err.message);
        res.status(500).json({ error: 'Failed to check payment status' });
    }
});

// ============================================================
// REFERRAL REWARD — Process referral bonuses
// ============================================================
app.post('/api/v1/referral/claim', async (req, res) => {
    const { referralCode, userId } = req.body;

    try {
        const referrer = await pool.query(
            'SELECT id FROM users WHERE referral_code = $1', [referralCode]
        ).then(r => r.rows[0]);

        if (!referrer) {
            return res.status(404).json({ error: 'Invalid referral code' });
        }

        // Check if referral record exists and hasn't been rewarded
        const existing = await pool.query(
            `SELECT * FROM referrals WHERE referrer_id = $1 AND referred_user_id = $2 AND reward_claimed = FALSE`,
            [referrer.id, userId]
        );

        if (existing.rows.length > 0) {
            const reward = 500;
            await pool.query(`
                UPDATE users SET referral_earnings = referral_earnings + $1 WHERE id = $2
            `, [reward, referrer.id]);

            await pool.query(`
                UPDATE referrals SET reward_claimed = TRUE WHERE id = $1
            `, [existing.rows[0].id]);

            logger.info(`Referral reward claimed: ${referrer.id} | KES ${reward}`);
            return res.json({ success: true, reward });
        }

        res.json({ success: false, message: 'No pending referral reward' });
    } catch (err) {
        logger.error('Referral claim error:', err);
        res.status(500).json({ error: 'Failed to claim referral reward' });
    }
});

// ============================================================
// PAYMENT TIERS — Get pricing
// ============================================================
app.get('/api/v1/tiers', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT tier_name, price_kes, domain_limit, dns_records_per_domain, features FROM service_tiers WHERE is_active = TRUE ORDER BY price_kes'
        );
        res.json(result.rows);
    } catch (err) {
        logger.error('Tiers fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch tiers' });
    }
});

// ============================================================
// BALANCE — Check user spending
// ============================================================
app.get('/api/v1/user/:userId/balance', async (req, res) => {
    const { userId } = req.params;

    try {
        const result = await pool.query(
            'SELECT total_spent, referral_earnings, tier FROM users WHERE id = $1', [userId]
        );
        if (!result.rows[0]) return res.status(404).json({ error: 'User not found' });
        res.json(result.rows[0]);
    } catch (err) {
        logger.error('Balance check error:', err);
        res.status(500).json({ error: 'Failed to fetch balance' });
    }
});

// ============================================================
// ERROR HANDLER
// ============================================================
app.use((err, req, res, next) => {
    logger.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// ============================================================
// START
// ============================================================
app.listen(PORT, '0.0.0.0', () => {
    logger.info(`M-PESA Gateway running on port ${PORT}`);
});
