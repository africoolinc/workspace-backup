/**
 * Mamaduka .Crypto — Cloudflare Sync Service
 * Syncs DNS records to Cloudflare Workers/DNS for CDN and DDoS protection
 */

require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');
const axios = require('axios');
const winston = require('winston');
const cron = require('node-cron');

const app = express();
const PORT = process.env.CLOUDFLARE_PORT || 3005;

// ============================================================
// LOGGING
// ============================================================
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: [
        new winston.transports.File({ filename: '/app/logs/cloudflare-error.log', level: 'error' }),
        new winston.transports.File({ filename: '/app/logs/cloudflare-combined.log' }),
        new winston.transports.Console({ format: winston.format.simple() })
    ]
});

// ============================================================
// DATABASE & CACHE
// ============================================================
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
const redis = new Redis(process.env.REDIS_URL);
redis.on('error', err => logger.error('Redis error:', err));

// ============================================================
// CLOUDFLARE API
// ============================================================
const CF_API_TOKEN = process.env.CLOUDFLARE_API_TOKEN;
const CF_ZONE_ID = process.env.CLOUDFLARE_ZONE_ID;
const CF_BASE_URL = 'https://api.cloudflare.com/client/v4';

const cfClient = axios.create({
    baseURL: CF_BASE_URL,
    headers: {
        Authorization: `Bearer ${CF_API_TOKEN}`,
        'Content-Type': 'application/json'
    },
    timeout: 10000
});

// ============================================================
// HELPERS
// ============================================================

// Get Cloudflare API token (cached)
async function getCFToken() {
    if (!CF_API_TOKEN) {
        throw new Error('Cloudflare API token not configured');
    }
    return CF_API_TOKEN;
}

// Transform our DNS record to Cloudflare format
function toCFRecord(record) {
    const type = record.record_type;
    const CF_TYPE_MAP = { A: 'A', AAAA: 'AAAA', CNAME: 'CNAME', TXT: 'TXT', MX: 'MX', NS: 'NS', SRV: 'SRV' };

    const cfRecord = {
        type: CF_TYPE_MAP[type] || type,
        name: record.record_name,
        content: record.record_value,
        ttl: record.ttl || 300,
        proxied: record.is_cloudflare_proxy || false
    };

    if (type === 'MX') {
        cfRecord.priority = record.priority || 10;
    }

    return cfRecord;
}

// ============================================================
// SYNC DNS RECORDS TO CLOUDFLARE
// ============================================================
async function syncDomainToCloudflare(domainName) {
    logger.info(`Syncing ${domainName} to Cloudflare...`);

    // Get domain from DB
    const domain = await pool.query(
        'SELECT id FROM domains WHERE domain_name = $1', [domainName]
    );

    if (!domain.rows[0]) {
        throw new Error(`Domain ${domainName} not found in database`);
    }

    // Get all DNS records
    const records = await pool.query(`
        SELECT dr.* FROM dns_records dr
        JOIN domains d ON dr.domain_id = d.id
        WHERE d.domain_name = $1
    `, [domainName]);

    logger.info(`Found ${records.rows.length} records for ${domainName}`);

    // Get existing CF records
    let existingCFRecords = [];
    try {
        const cfResponse = await cfClient.get(`/zones/${CF_ZONE_ID}/dns_records`);
        existingCFRecords = cfResponse.data.result || [];
    } catch (err) {
        logger.warn('Could not fetch existing CF records:', err.response?.data);
    }

    // Group records by name+type for matching
    const cfRecordMap = new Map();
    for (const rec of existingCFRecords) {
        const key = `${rec.name}:${rec.type}`;
        cfRecordMap.set(key, rec);
    }

    const synced = [];
    const errors = [];

    for (const record of records.rows) {
        try {
            const cfRecord = toCFRecord(record);
            const key = `${cfRecord.name}:${cfRecord.type}`;
            const existing = cfRecordMap.get(key);

            if (existing) {
                // Update existing record
                await cfClient.put(`/zones/${CF_ZONE_ID}/dns_records/${existing.id}`, cfRecord);
                logger.info(`Updated CF record: ${cfRecord.name} ${cfRecord.type}`);
            } else {
                // Create new record
                await cfClient.post(`/zones/${CF_ZONE_ID}/dns_records`, cfRecord);
                logger.info(`Created CF record: ${cfRecord.name} ${cfRecord.type}`);
            }

            synced.push(key);

            // Mark as cloudflare synced in our DB
            await pool.query(
                'UPDATE dns_records SET is_cloudflare_proxy = $1 WHERE id = $2',
                [cfRecord.proxied, record.id]
            );

        } catch (err) {
            logger.error(`Failed to sync record ${record.record_name}:`, err.response?.data || err.message);
            errors.push({ record: record.record_name, error: err.message });
        }
    }

    // Purge Cloudflare cache for the domain
    try {
        await cfClient.delete(`/zones/${CF_ZONE_ID}/purge_cache`, {
            data: { files: [`https://${domainName}/*`, `https://www.${domainName}/*`] }
        });
        logger.info(`Cloudflare cache purged for ${domainName}`);
    } catch (err) {
        logger.warn('Cache purge failed:', err.response?.data);
    }

    return { synced: synced.length, errors };
}

// ============================================================
// FULL SYNC
// ============================================================
async function fullSync() {
    logger.info('Starting full Cloudflare sync...');

    try {
        // Get all domains with active DNS records
        const domains = await pool.query(`
            SELECT DISTINCT d.domain_name
            FROM domains d
            JOIN dns_records dr ON dr.domain_id = d.id
            WHERE d.is_active = TRUE
        `);

        const results = [];
        for (const { domain_name } of domains.rows) {
            try {
                const result = await syncDomainToCloudflare(domain_name);
                results.push({ domain: domain_name, ...result });
            } catch (err) {
                logger.error(`Sync failed for ${domain_name}:`, err.message);
                results.push({ domain: domain_name, error: err.message });
            }
        }

        logger.info(`Full sync complete: ${results.length} domains processed`);
        return results;

    } catch (err) {
        logger.error('Full sync error:', err);
        throw err;
    }
}

// ============================================================
// SYNC ALL DOMAINS FOR A USER
// ============================================================
async function syncUserDomains(userId) {
    const domains = await pool.query(`
        SELECT domain_name FROM domains WHERE owner_user_id = $1 AND is_active = TRUE
    `, [userId]);

    const results = [];
    for (const { domain_name } of domains.rows) {
        const result = await syncDomainToCloudflare(domain_name);
        results.push({ domain: domain_name, ...result });
    }

    return results;
}

// ============================================================
// CLOUDFLARE WORKER — DNS-over-HTTPS proxy
// ============================================================

// Serve a DNS-over-HTTPS endpoint that routes .crypto queries to our DNS resolver
async function setupDoHWorker() {
    if (!CF_API_TOKEN) {
        logger.warn('No Cloudflare token — skipping DoH Worker setup');
        return;
    }

    try {
        // Check if worker exists
        const workers = await cfClient.get(`/zones/${CF_ZONE_ID}/workers/scripts`);
        logger.info('Cloudflare Workers available');
    } catch (err) {
        logger.warn('Workers not available or not configured');
    }
}

// ============================================================
// API ROUTES
// ============================================================
app.use(express.json());

app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'cloudflare-sync' });
});

// Trigger full sync
app.post('/api/v1/sync/full', async (req, res) => {
    try {
        const results = await fullSync();
        res.json({ success: true, results });
    } catch (err) {
        logger.error('Full sync API error:', err);
        res.status(500).json({ error: 'Full sync failed' });
    }
});

// Sync single domain
app.post('/api/v1/sync/domain/:domain', async (req, res) => {
    try {
        const { domain } = req.params;
        const result = await syncDomainToCloudflare(domain.endsWith('.crypto') ? domain : domain + '.crypto');
        res.json({ success: true, ...result });
    } catch (err) {
        logger.error('Domain sync error:', err);
        res.status(500).json({ error: err.message });
    }
});

// Sync all domains for user
app.post('/api/v1/sync/user/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const results = await syncUserDomains(userId);
        res.json({ success: true, results });
    } catch (err) {
        logger.error('User sync error:', err);
        res.status(500).json({ error: 'Sync failed' });
    }
});

// Get Cloudflare zone DNS records
app.get('/api/v1/cloudflare/records', async (req, res) => {
    try {
        const response = await cfClient.get(`/zones/${CF_ZONE_ID}/dns_records`);
        res.json(response.data.result);
    } catch (err) {
        logger.error('CF records fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch Cloudflare records' });
    }
});

// Get sync status
app.get('/api/v1/sync/status', async (req, res) => {
    try {
        const stats = await pool.query(`
            SELECT
                COUNT(DISTINCT d.domain_name) as total_synced_domains,
                COUNT(dr.id) FILTER (WHERE dr.is_cloudflare_proxy = TRUE) as proxied_records,
                MAX(dr.updated_at) as last_sync
            FROM dns_records dr
            JOIN domains d ON dr.domain_id = d.id
        `);
        res.json(stats.rows[0]);
    } catch (err) {
        logger.error('Sync status error:', err);
        res.status(500).json({ error: 'Failed to get sync status' });
    }
});

// Manual cache purge
app.post('/api/v1/cloudflare/purge', async (req, res) => {
    const { domain } = req.body;

    try {
        await cfClient.delete(`/zones/${CF_ZONE_ID}/purge_cache`, {
            data: {
                hosts: [domain, `www.${domain}`],
                files: [`https://${domain}/*`]
            }
        });
        res.json({ success: true, message: `Cache purged for ${domain}` });
    } catch (err) {
        logger.error('Cache purge error:', err);
        res.status(500).json({ error: 'Purge failed' });
    }
});

// Cloudflare Analytics
app.get('/api/v1/cloudflare/analytics', async (req, res) => {
    try {
        const since = Date.now() - 86400000; // last 24h
        const response = await cfClient.get(
            `/zones/${CF_ZONE_ID}/analytics/dashboard`,
            { params: { since: Math.floor(since / 1000) } }
        );
        res.json(response.data);
    } catch (err) {
        logger.error('CF analytics error:', err);
        res.status(500).json({ error: 'Failed to fetch analytics' });
    }
});

// Metrics
app.get('/metrics', async (req, res) => {
    try {
        const stats = await pool.query(`
            SELECT
                COUNT(DISTINCT domain_id) as domains_with_cf,
                COUNT(*) FILTER (WHERE is_cloudflare_proxy = TRUE) as proxied_records
            FROM dns_records
        `);
        res.json(stats.rows[0]);
    } catch (err) {
        logger.error('Metrics error:', err);
        res.status(500).json({ error: 'Metrics failed' });
    }
});

// ============================================================
// STARTUP
// ============================================================
async function start() {
    logger.info('Starting Cloudflare Sync service...');
    logger.info(`Zone ID: ${CF_ZONE_ID ? CF_ZONE_ID.slice(0, 8) + '...' : 'NOT SET'}`);

    // Initial full sync
    try {
        await fullSync();
    } catch (err) {
        logger.warn('Initial sync skipped (may need credentials):', err.message);
    }

    // Periodic sync every 5 minutes
    cron.schedule('*/5 * * * *', async () => {
        try {
            await fullSync();
        } catch (err) {
            logger.error('Scheduled sync failed:', err.message);
        }
    });

    app.listen(PORT, '0.0.0.0', () => {
        logger.info(`Cloudflare Sync listening on port ${PORT}`);
    });
}

start().catch(err => {
    logger.error('Startup failed:', err);
    process.exit(1);
});
