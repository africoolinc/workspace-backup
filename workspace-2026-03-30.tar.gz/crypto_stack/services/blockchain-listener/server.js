/**
 * Mamaduka .Crypto — Blockchain Listener
 * Monitors Ethereum ENS .crypto registry for domain registrations
 */

require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');
const { ethers } = require('ethers');
const winston = require('winston');
const cron = require('node-cron');

const app = express();
const PORT = process.env.BLOCKCHAIN_PORT || 3003;

// ============================================================
// LOGGING
// ============================================================
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: [
        new winston.transports.File({ filename: '/app/logs/blockchain-error.log', level: 'error' }),
        new winston.transports.File({ filename: '/app/logs/blockchain-combined.log' }),
        new winston.transports.Console({ format: winston.format.simple() })
    ]
});

// ============================================================
// DATABASE & CACHE
// ============================================================
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
const redis = new Redis(process.env.REDIS_URL);
redis.on('error', err => logger.error('Redis error:', err));

// ============================================================
// ETHEREUM PROVIDER — non-blocking polling provider
// ============================================================
let provider;

async function getProvider() {
    if (!provider) {
        const { JsonRpcProvider, FallbackProvider } = require('ethers');

        // Try multiple free public RPC endpoints
        const rpcUrls = [
            'https://rpc.llamRPC.com',
            'https://rpc.ankr.com/eth',
            'https://eth.llamarpc.io'
        ];

        const providers = rpcUrls.map(url => new JsonRpcProvider({
            url,
            skipFetchSetup: true,
            headers: { 'Accept': 'application/json' }
        }));

        // Use fallback provider — tries each RPC, doesn't block on failure
        provider = providers[0]; // start with first, ethers will handle retries

        logger.info(`Ethereum provider configured with: ${rpcUrls[0]}`);
    }
    return provider;
}
const ENS_REGISTRY = process.env.ENS_REGISTRY || '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
const DOMAIN_OWNER_KEY = process.env.DOMAIN_OWNER_KEY;
const CHAIN_ID = parseInt(process.env.CHAIN_ID || '1');

// ============================================================
// ENS REGISTRY ABI (simplified — only events we care about)
// ============================================================
const ENS_ABI = [
    'event NewOwner(bytes32 indexed node, bytes32 indexed label, address owner)',
    'event Transfer(bytes32 indexed node, address owner)',
    'event NewResolver(bytes32 indexed node, address resolver)',
    'event NewTTL(bytes32 indexed node, uint64 ttl)',
    'function owner(bytes32 node) view returns (address)',
    'function resolver(bytes32 node) view returns (address)',
    'function ttl(bytes32 node) view returns (uint64)',
    'function setOwner(bytes32 node, address owner)',
    'function setResolver(bytes32 node, address resolver)',
    'function setTTL(bytes32 node, uint64 ttl)',
    'function setSubnodeOwner(bytes32 node, bytes32 label, address owner)'
];

let ensContract;

async function getEnsContract() {
    if (!ensContract) {
        const prov = await getProvider();
        ensContract = new ethers.Contract(ENS_REGISTRY, ENS_ABI, prov);
    }
    return ensContract;
}

// ============================================================
// HELPERS
// ============================================================

// Label to hash (for ENS subdomains)
function labelHash(label) {
    return ethers.id(label.toLowerCase()).slice(0, 10) + '0000000000000000000000000000000000000000';
}

// Namehash for domain
function namehash(name) {
    let node = '0x0000000000000000000000000000000000000000000000000000000000000000';
    if (name) {
        const labels = name.split('.');
        for (let i = labels.length - 1; i >= 0; i--) {
            const labelHash = ethers.id(labels[i].toLowerCase());
            node = ethers.keccak256(Buffer.concat([
                Buffer.from(node.slice(2), 'hex'),
                Buffer.from(labelHash.slice(2), 'hex')
            ]));
        }
    }
    return node;
}

// Normalize .crypto domain
function normalizeDomain(name) {
    return name.toLowerCase().replace(/\.crypto$/, '') + '.crypto';
}

// Process domain event
async function processDomainEvent(eventType, tokenId, owner, resolver, domainName, blockNumber, txHash) {
    logger.info(`Processing ${eventType}: ${domainName} -> ${owner}`);

    const existing = await pool.query(
        'SELECT id FROM domains WHERE token_id = $1', [tokenId]
    );

    if (eventType === 'Transfer' || eventType === 'NewOwner') {
        if (existing.rows.length > 0) {
            await pool.query(`
                UPDATE domains SET owner_address = $1, resolver_address = $2, updated_at = NOW()
                WHERE token_id = $3
            `, [owner, resolver, tokenId]);
        } else {
            await pool.query(`
                INSERT INTO domains (token_id, domain_name, label_name, owner_address, resolver_address, registration_block, nft_token_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            `, [tokenId, domainName, domainName.split('.')[0], owner, resolver, blockNumber, parseInt(tokenId.slice(0, 18), 16)]);
        }

        // Invalidate DNS cache
        await redis.del(`dns:domain:${domainName}`);
        await redis.del(`dns:resolve:${domainName}`);
    }

    // Record blockchain event
    await pool.query(`
        INSERT INTO blockchain_events (event_type, chain_id, transaction_hash, block_number, contract_address, event_data, processed, processed_at)
        VALUES ($1, $2, $3, $4, $5, $6, TRUE, NOW())
    `, [eventType, CHAIN_ID, txHash, blockNumber, ENS_REGISTRY, JSON.stringify({ tokenId, owner, resolver, domainName })]);
}

// ============================================================
// SYNC FROM BLOCKCHAIN
// ============================================================
async function syncFromBlockchain() {
    logger.info('Starting blockchain sync...');
    const lastBlock = await pool.query(
        'SELECT COALESCE(MAX(block_number), 0) as block FROM blockchain_events WHERE chain_id = $1',
        [CHAIN_ID]
    ).then(r => parseInt(r.rows[0].block));

    const currentBlock = await (await getProvider()).getBlockNumber().catch(e => { logger.warn("RPC unreachable:", e.message); return null; }); if (!currentBlock) return;;
    const fromBlock = Math.max(lastBlock - 1, 0); // re-check last block for edge cases
    const toBlock = Math.min(fromBlock + 1000, currentBlock); // batch of 1000

    logger.info(`Syncing blocks ${fromBlock} to ${toBlock}`);

    try {
        // Get Transfer events
        const contract = await getEnsContract(); const transferFilter = contract.filters.Transfer();
        const transfers = await contract.queryFilter(transferFilter, fromBlock, toBlock);

        for (const event of transfers) {
            const node = event.args.node;
            const owner = event.args.owner;
            const tokenId = node; // In ENS, node = tokenId for reverse resolution
            const label = Buffer.from(event.args.tokenId ? 'crypto' : 'crypto').toString();
            const domainName = label + '.crypto';

            // Only process .crypto domains
            if (label === 'crypto') {
                await processDomainEvent('Transfer', tokenId, owner, null, domainName, event.blockNumber, event.transactionHash);
            }
        }

        // Get NewOwner events
        const newOwnerFilter = contract.filters.NewOwner();
        const newOwners = await contract.queryFilter(newOwnerFilter, fromBlock, toBlock);

        for (const event of newOwners) {
            const node = event.args.node;
            const label = event.args.label;
            const owner = event.args.owner;
            const tokenId = ethers.keccak256(Buffer.concat([
                Buffer.from(node.slice(2), 'hex'),
                Buffer.from(label.slice(2), 'hex')
            ]));
            const domainName = label + '.crypto';

            if (label === 'crypto' || event.args.node === namehash('crypto')) {
                await processDomainEvent('NewOwner', tokenId, owner, null, domainName, event.blockNumber, event.transactionHash);
            }
        }

        logger.info(`Sync complete. Processed ${transfers.length + newOwners.length} events`);
    } catch (err) {
        logger.error('Blockchain sync error:', err.message);
    }
}

// ============================================================
// BLOCK LISTENER (real-time)
// ============================================================
async function startBlockListener() {
    logger.info('Starting real-time block listener...');

    try {
        // Listen for Transfer events
        (await getEnsContract()).on('Transfer', async (node, owner) => {
            const domainName = 'crypto'; // Simplified - real impl would do reverse lookup
            const tokenId = node;
            logger.info(`[LISTENER] Transfer: ${tokenId} -> ${owner}`);
            await processDomainEvent('Transfer', tokenId, owner, null, domainName + '.crypto', null, null);
        });

        // Listen for NewOwner events
        (await getEnsContract()).on('NewOwner', async (node, label, owner) => {
            const tokenId = ethers.keccak256(Buffer.concat([
                Buffer.from(node.slice(2), 'hex'),
                Buffer.from(label.slice(2), 'hex')
            ]));
            const domainName = label + '.crypto';
            logger.info(`[LISTENER] NewOwner: ${domainName} -> ${owner}`);
            await processDomainEvent('NewOwner', tokenId, owner, null, domainName, null, null);
        });

        // Listen for NewResolver events
        (await getEnsContract()).on('NewResolver', async (node, resolver) => {
            logger.info(`[LISTENER] NewResolver: ${node} -> ${resolver}`);
        });

        logger.info('Block listener started successfully');
    } catch (err) {
        logger.error('Failed to start block listener:', err.message);
    }
}

// ============================================================
// API ROUTES
// ============================================================
app.use(express.json());

app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'blockchain-listener', block: 'syncing' });
});

app.get('/api/v1/domains', async (req, res) => {
    try {
        const { page = 1, limit = 50 } = req.query;
        const result = await pool.query(`
            SELECT d.*, u.full_name as owner_name, u.email as owner_email
            FROM domains d LEFT JOIN users u ON d.owner_user_id = u.id
            ORDER BY d.created_at DESC
            LIMIT $1 OFFSET $2
        `, [limit, (page - 1) * limit]);
        res.json(result.rows);
    } catch (err) {
        logger.error('Domains fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch domains' });
    }
});

app.get('/api/v1/domains/:name', async (req, res) => {
    try {
        const { name } = req.params;
        const normalized = normalizeDomain(name);

        const cached = await redis.get(`blockchain:domain:${normalized}`);
        if (cached) return res.json(JSON.parse(cached));

        const result = await pool.query(
            'SELECT * FROM domains WHERE domain_name = $1', [normalized]
        );

        if (result.rows[0]) {
            await redis.setex(`blockchain:domain:${normalized}`, 300, JSON.stringify(result.rows[0]));
            res.json(result.rows[0]);
        } else {
            res.status(404).json({ error: 'Domain not found' });
        }
    } catch (err) {
        logger.error('Domain lookup error:', err);
        res.status(500).json({ error: 'Failed to lookup domain' });
    }
});

app.get('/api/v1/owner/:address/domains', async (req, res) => {
    try {
        const { address } = req.params;
        const result = await pool.query(
            'SELECT * FROM domains WHERE owner_address = $1 ORDER BY created_at DESC', [address]
        );
        res.json(result.rows);
    } catch (err) {
        logger.error('Owner domains error:', err);
        res.status(500).json({ error: 'Failed to fetch domains' });
    }
});

app.get('/api/v1/blockchain/status', async (req, res) => {
    try {
        const blockNumber = await (await getProvider()).getBlockNumber().catch(() => 0);
        const lastEvent = await pool.query(
            'SELECT block_number, created_at FROM blockchain_events ORDER BY created_at DESC LIMIT 1'
        );
        res.json({
            currentBlock: blockNumber,
            lastProcessedBlock: lastEvent.rows[0]?.block_number || 0,
            lastProcessedAt: lastEvent.rows[0]?.created_at || null,
            chainId: CHAIN_ID
        });
    } catch (err) {
        logger.error('Blockchain status error:', err);
        res.status(500).json({ error: 'Failed to get blockchain status' });
    }
});

app.post('/api/v1/sync', async (req, res) => {
    try {
        await syncFromBlockchain();
        res.json({ success: true, message: 'Sync triggered' });
    } catch (err) {
        logger.error('Manual sync error:', err);
        res.status(500).json({ error: 'Sync failed' });
    }
});

// Metrics endpoint
app.get('/metrics', async (req, res) => {
    const stats = await pool.query(`
        SELECT COUNT(*) as total_domains,
               COUNT(DISTINCT owner_address) as unique_owners,
               MAX(created_at) as last_registration
        FROM domains
    `);
    res.json(stats.rows[0]);
});

// ============================================================
// STARTUP
// ============================================================
async function start() {
    logger.info('Starting Blockchain Listener...');
    logger.info(`ENS Registry: ${ENS_REGISTRY}`);
    logger.info(`Chain ID: ${CHAIN_ID}`);

    // Initial sync — non-blocking, retry in background
    syncFromBlockchain().catch(err => {
        logger.warn('Initial sync skipped (RPC may need credentials):', err.message);
    });

    // Start real-time listener — non-blocking with retry
    setTimeout(() => startBlockListener().catch(err => {
        logger.warn('Block listener retry in 30s:', err.message);
        setTimeout(startBlockListener, 30000);
    }), 2000);

    // Periodic full sync every 5 minutes
    cron.schedule('*/5 * * * *', () => syncFromBlockchain().catch(err => {
        logger.error('Scheduled sync error:', err.message);
    }));

    app.listen(PORT, '0.0.0.0', () => {
        logger.info(`Blockchain Listener running on port ${PORT}`);
    });
}

start();
