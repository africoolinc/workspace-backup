-- ============================================================
-- Mamaduka .Crypto Domain Registrar — Database Schema
-- PostgreSQL Init
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    normalized_phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255),
    password_hash VARCHAR(255),
    full_name VARCHAR(255),
    mpesa_account VARCHAR(20),
    tier VARCHAR(20) DEFAULT 'starter' CHECK (tier IN ('starter', 'professional', 'enterprise')),
    is_verified BOOLEAN DEFAULT FALSE,
    verification_code VARCHAR(6),
    verification_expires_at TIMESTAMP WITH TIME ZONE,
    referral_code VARCHAR(20) UNIQUE NOT NULL,
    referred_by UUID REFERENCES users(id),
    referral_earnings DECIMAL(12,2) DEFAULT 0,
    total_spent DECIMAL(12,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP WITH TIME ZONE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone ON users(normalized_phone);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_referral ON users(referral_code);

-- ============================================================
-- DOMAINS
-- ============================================================
CREATE TABLE IF NOT EXISTS domains (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id VARCHAR(66) UNIQUE NOT NULL,
    domain_name VARCHAR(255) NOT NULL,
    label_name VARCHAR(63) NOT NULL,
    owner_address VARCHAR(42) NOT NULL,
    owner_user_id UUID REFERENCES users(id),
    resolver_address VARCHAR(42),
    nft_token_id BIGINT,
    registration_block BIGINT,
    expiry_date TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_domains_name ON domains(domain_name);
CREATE INDEX IF NOT EXISTS idx_domains_owner_address ON domains(owner_address);
CREATE INDEX IF NOT EXISTS idx_domains_owner_user ON domains(owner_user_id);

-- ============================================================
-- DNS RECORDS
-- ============================================================
CREATE TABLE IF NOT EXISTS dns_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    domain_id UUID NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    record_type VARCHAR(10) NOT NULL CHECK (record_type IN ('A','AAAA','CNAME','TXT','MX','NS','SRV')),
    record_name VARCHAR(255) NOT NULL,
    record_value TEXT NOT NULL,
    priority INTEGER DEFAULT 0,
    ttl INTEGER DEFAULT 300,
    is_cloudflare_proxy BOOLEAN DEFAULT FALSE,
    cached_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_dns_domain ON dns_records(domain_id);
CREATE INDEX IF NOT EXISTS idx_dns_type ON dns_records(record_type);

-- ============================================================
-- PAYMENTS (M-PESA)
-- ============================================================
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    checkout_request_id VARCHAR(100) UNIQUE,
    merchant_request_id VARCHAR(100),
    transaction_id VARCHAR(50) UNIQUE,
    user_id UUID NOT NULL REFERENCES users(id),
    phone_number VARCHAR(20) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'KES',
    domain_id UUID REFERENCES domains(id),
    domain_name VARCHAR(255),
    tier VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','processing','completed','failed','refunded','cancelled')),
    result_code VARCHAR(10),
    result_desc TEXT,
    receipt_number VARCHAR(50),
    transaction_date TIMESTAMP WITH TIME ZONE,
    payment_type VARCHAR(20) DEFAULT 'stk_push',
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_transaction ON payments(transaction_id);

-- ============================================================
-- SERVICE TIERS
-- ============================================================
CREATE TABLE IF NOT EXISTS service_tiers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tier_name VARCHAR(20) UNIQUE NOT NULL,
    price_kes DECIMAL(10,2) NOT NULL,
    domain_limit INTEGER DEFAULT 1,
    dns_records_per_domain INTEGER DEFAULT 10,
    phone_verifications INTEGER DEFAULT 5,
    api_rate_limit INTEGER DEFAULT 100,
    features JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Seed default tiers
INSERT INTO service_tiers (tier_name, price_kes, domain_limit, dns_records_per_domain, phone_verifications, api_rate_limit, features) VALUES
    ('starter', 1500, 2, 10, 3, 100, '["basic_dns","phone_verification","dashboard_access"]'),
    ('professional', 3500, 10, 50, 10, 500, '["advanced_dns","cloudflare_sync","api_access","priority_support"]'),
    ('enterprise', 15000, -1, -1, -1, 5000, '["unlimited_domains","unlimited_records","whitelabel","dedicated_support","custom_dns_servers"]')
ON CONFLICT (tier_name) DO NOTHING;

-- ============================================================
-- REFERRALS
-- ============================================================
CREATE TABLE IF NOT EXISTS referrals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    referrer_id UUID NOT NULL REFERENCES users(id),
    referred_user_id UUID NOT NULL REFERENCES users(id),
    payment_id UUID REFERENCES payments(id),
    reward_amount DECIMAL(10,2) DEFAULT 500,
    reward_claimed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred ON referrals(referred_user_id);

-- ============================================================
-- BLOCKCHAIN EVENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS blockchain_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(50) NOT NULL,
    chain_id INTEGER NOT NULL,
    transaction_hash VARCHAR(66) UNIQUE NOT NULL,
    block_number BIGINT NOT NULL,
    block_hash VARCHAR(66),
    contract_address VARCHAR(42),
    event_data JSONB NOT NULL,
    processed BOOLEAN DEFAULT FALSE,
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_events_processed ON blockchain_events(processed, created_at);
CREATE INDEX IF NOT EXISTS idx_events_tx ON blockchain_events(transaction_hash);

-- ============================================================
-- API KEYS
-- ============================================================
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key_hash VARCHAR(64) UNIQUE NOT NULL,
    key_prefix VARCHAR(8) NOT NULL,
    name VARCHAR(100),
    permissions JSONB DEFAULT '["read"]',
    rate_limit INTEGER DEFAULT 100,
    last_used_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_apikeys_user ON api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_apikeys_hash ON api_keys(key_hash);

-- ============================================================
-- TIMESTAMP FUNCTIONS
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at triggers
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_domains_updated_at ON domains;
CREATE TRIGGER update_domains_updated_at BEFORE UPDATE ON domains FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_dns_records_updated_at ON dns_records;
CREATE TRIGGER update_dns_records_updated_at BEFORE UPDATE ON dns_records FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================

-- Normalize phone number (Kenyan format)
CREATE OR REPLACE FUNCTION normalize_phone(phone VARCHAR)
RETURNS VARCHAR AS $$
DECLARE
    cleaned VARCHAR;
BEGIN
    cleaned := regexp_replace(phone, '[^\d+]', '', 'g');
    IF cleaned LIKE '0%' THEN
        cleaned := '+254' || substring(cleaned from 2);
    ELSIF cleaned LIKE '254%' THEN
        cleaned := '+' || cleaned;
    ELSIF cleaned NOT LIKE '+%' THEN
        cleaned := '+254' || cleaned;
    END IF;
    RETURN cleaned;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Generate referral code
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS VARCHAR AS $$
DECLARE
    chars VARCHAR := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    result VARCHAR := '';
    i INTEGER;
BEGIN
    FOR i IN 1..8 LOOP
        result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
    END LOOP;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Seed a test user (for development)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM users WHERE phone_number = '+254700123456') THEN
        INSERT INTO users (phone_number, normalized_phone, full_name, tier, is_verified, referral_code, mpesa_account)
        VALUES (
            '+254700123456',
            '+254700123456',
            'Gibson Test',
            'professional',
            TRUE,
            generate_referral_code(),
            '700123456'
        );
    END IF;
END $$;
