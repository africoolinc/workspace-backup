# sim_config.sh — Configuration for SIM diagnostics probes
# Copy to Termux: ~/.termux/sim-diagnostics/sim_config.sh
# Copy to Linux host: /root/.openclaw/workspace/sim-diagnostics/sim_config.sh
#
# Telegram alerts (recommended):
#   1. Create a bot via @BotFather → get the bot token
#   2. Start a chat with your bot, then get your chat_id via:
#      https://api.telegram.org/bot<TOKEN>/getUpdates
#   3. Fill in below

TELEGRAM_BOT_TOKEN=""
TELEGRAM_CHAT_ID=""

# Alert triggers
ALERT_ON_CHANGE="true"

# Archive logs older than N days (set to 0 to disable archiving)
ARCHIVE_DAYS="30"

# Path to last state file (for change detection)
LAST_STATE_FILE=""

# Cron schedule: every 3 hours
# On Termux: use termux-boot or termux-tasker for persistent background scheduling
# On Linux:  use standard cron
CRON_SCHEDULE="0 */3 * * *"
