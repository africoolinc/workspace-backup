#!/bin/bash
# sim_probe.sh — Termux SIM & network diagnostics probe
# Run standalone: bash sim_probe.sh
# Run via cron:    logrun bash /data/data/com.termux/files/home/.termux/sim-diagnostics/sim_probe.sh
#
# Dependencies (Termux): pkg install termux-api coreutils jq
# Non-Termux fallback:   pkg install mmcli (Linux with ModemManager)
#
# Output: JSON + human-readable to stdout, raw log to $LOG_DIR/YYYY-MM-DD_HH.log
# Alert:  Sends Telegram message on carrier/APN change or SIM removal

set -euo pipefail

LOG_DIR="/data/data/com.termux/files/home/.termux/sim-diagnostics/logs"
ASSETS_DIR="$(dirname "$0")"
CONFIG_FILE="$ASSETS_DIR/sim_config.sh"
ARCHIVED="$LOG_DIR/archived"

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S %z')
TIMESTAMP_FILE=$(date '+%Y-%m-%d_%H')
DATE=$(date '+%Y-%m-%d')
HOST=$(hostname)
ARCHIVE_DAYS=14

# ── Load config ────────────────────────────────────────────────────────────────
[ -f "$CONFIG_FILE" ] && source "$CONFIG_FILE"

TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-}"
ALERT_ON_CHANGE="${ALERT_ON_CHANGE:-true}"
LAST_STATE_FILE="${LAST_STATE_FILE:-$ASSETS_DIR/.last_state.json}"

mkdir -p "$LOG_DIR" "$ARCHIVED"

# ── Helpers ───────────────────────────────────────────────────────────────────
jq_escape() { printf '%s' "$1" | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read()))'; }

log_rotate() {
  # Archive logs older than ARCHIVE_DAYS
  find "$LOG_DIR" -maxdepth 1 -name "*.log" -mtime +"$ARCHIVE_DAYS" -exec mv -t "$ARCHIVED" {} +
}

get_prev_state() {
  if [ -f "$LAST_STATE_FILE" ]; then
    cat "$LAST_STATE_FILE"
  else
    echo "{}"
  fi
}

save_curr_state() {
  python3 -c "import sys,json; d=json.loads(sys.stdin.read()); d.pop('_raw',None); print(json.dumps(d))" \
    > "$LAST_STATE_FILE"
}

telegram_alert() {
  local msg="$1"
  [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ] && return 0
  local payload
  payload=$(python3 -c "import sys,json; print(json.dumps({'chat_id':${TELEGRAM_CHAT_ID},'text':${TELEGRAM_BOT_TOKEN:+${TELEGRAM_BOT_TOKEN}}))}" 2>/dev/null || echo "{}")
  curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d "chat_id=${TELEGRAM_CHAT_ID}" \
    -d "text=${msg}" \
    -d "parse_mode=HTML" \
    --max-time 10 > /dev/null 2>&1 || true
}

# ── Probe Functions ──────────────────────────────────────────────────────────

probe_sim_termux() {
  # Use termux-sim-status (part of termux-api package)
  local sim_status iccid operator sim_operator_name sim_operator_numeric
  local sim_country sim_network_type sim_signal_strength sim_call_state

  sim_status=$(termux-sim-status 2>/dev/null) || sim_status="{}"

  iccid=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('iccid','UNKNOWN'))" 2>/dev/null || echo "ERROR")
  operator=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('operator',''))" 2>/dev/null || echo "")
  sim_operator_name=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sim_operator_name',''))" 2>/dev/null || echo "")
  sim_operator_numeric=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sim_operator_numeric',''))" 2>/dev/null || echo "")
  sim_country=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sim_country',''))" 2>/dev/null || echo "")
  sim_network_type=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('network_type',''))" 2>/dev/null || echo "")
  sim_signal_strength=$(echo "$sim_status" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('signal_strength',''))" 2>/dev/null || echo "")
  sim_call_state=$(echo "$sim_status" | python-status 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('call_state',''))" 2>/dev/null || echo "UNKNOWN")

  # termux-wifi-connectioninfo
  local wifi_ssid wifi_link_speed wifi_rssi wifi_frequency wifi_ip
  local wifi_info
  wifi_info=$(termux-wifi-connectioninfo 2>/dev/null) || wifi_info="{}"
  wifi_ssid=$(echo "$wifi_info" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('ssid',''))" 2>/dev/null || echo "")
  wifi_rssi=$(echo "$wifi_info" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('rssi',''))" 2>/dev/null || echo "")
  wifi_link_speed=$(echo "$wifi_info" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('link_speed',''))" 2>/dev/null || echo "")

  # Network state
  local data_enabled airplane_mode
  data_enabled=$(termux-telephony-deviceinfo 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('data_enabled',''))" 2>/dev/null || echo "")
  airplane_mode=$(getprop ro.airplane.mode 2>/dev/null || echo "")

  cat <<EOF
{
  "probe": "termux-api",
  "host": "$HOST",
  "timestamp": "$TIMESTAMP",
  "sim": {
    "present": true,
    "iccid": "$iccid",
    "operator": "$operator",
    "operator_name": "$sim_operator_name",
    "operator_numeric": "$sim_operator_numeric",
    "country": "$sim_country",
    "network_type": "$sim_network_type",
    "signal_strength": "$sim_signal_strength",
    "call_state": "$sim_call_state",
    "data_enabled": "$data_enabled"
  },
  "wifi": {
    "connected": $([ -n "$wifi_ssid" ] && echo "true" || echo "false"),
    "ssid": "$wifi_ssid",
    "rssi": "$wifi_rssi",
    "link_speed": "$wifi_link_speed"
  },
  "system": {
    "airplane_mode": "$airplane_mode"
  }
}
EOF
}

probe_sim_mmcli() {
  # ModemManager fallback on Linux
  local mdb="$LOG_DIR/.mm_dump_$$"
  mmcli -m any -J > "$mdb" 2>/dev/null || { rm -f "$mdb"; return 1; }

  local basic=$(python3 -c "
import sys, json
d = json.load(open('$mdb'))
m = d.get('modem',{})
b = m.get('bearer',{})
p = m.get('sim',{})
print(json.dumps({
  'operator_name': m.get('operator-name',''),
  'operator_code': m.get('operator-code',''),
  'signal_quality': m.get('signal-quality',{}).get('value',''),
  'access_technologies': m.get('access-technologies',[{}])[0].get('value',''),
  'sim_operator_id': p.get('sim-identifier',''),
  'sim_operator_name': p.get('sim-operator-name',''),
  'bearer_apn': b.get('properties',{}).get('apn',''),
  'ip_timeout': b.get('properties',{}).get('ip-timeout',''),
}))
" 2>/dev/null)
  rm -f "$mdb"
  echo "$basic"
}

probe_basestation_android() {
  # Query cell towers via dumpsys (requires Android)
  local cell_info=""
  cell_info=$(dumpsys telephony.registry 2>/dev/null | grep -E "mCellLocation|phoneType|networkType|operator" | head -20) || cell_info=""
  echo "$cell_info"
}

probe_basestation_generic() {
  # Linux: query via atinout or qmicli
  local at_cmd="AT+COPS?\r\n"
  local cops_resp=""
  if command -v atinout &>/dev/null; then
    cops_resp=$(echo -e "$at_cmd" | atinout - /dev/ttyUSB2 - 2>/dev/null) || cops_resp=""
  fi
  echo "$cops_resp"
}

# ── Build combined JSON ───────────────────────────────────────────────────────

detect_platform() {
  if [ -d "/data/data/com.termux" ]; then
    echo "termux"
  elif command -v mmcli &>/dev/null; then
    echo "mmcli"
  else
    echo "generic"
  fi
}

PLATFORM=$(detect_platform)

if [ "$PLATFORM" = "termux" ]; then
  PROBE_JSON=$(probe_sim_termux)
elif [ "$PLATFORM" = "mmcli" ]; then
  PROBE_JSON=$(probe_sim_mmcli)
else
  # Generic fallback
  PROBE_JSON=$(probe_basestation_generic 2>/dev/null)
fi

# Wrap with basestation data
BASESTATION=$(probe_basestation_android 2>/dev/null || echo "")
BASESTATION_ESCAPED=$(jq_escape "$BASESTATION")

FINAL_JSON=$(python3 -c "
import sys, json

probe = json.loads('''$PROBE_JSON''')
probe['basestation_dump'] = '''$BASESTATION'''

# Enrich with previous state for change detection
prev = json.loads('''$(get_prev_state)''')
probe['_prev'] = prev

# Change detection
changes = []
if prev:
    prev_iccid = prev.get('sim',{}).get('iccid','')
    curr_iccid = probe.get('sim',{}).get('iccid','')
    prev_op   = prev.get('sim',{}).get('operator','')
    curr_op   = probe.get('sim',{}).get('operator','')
    if prev_iccid and prev_iccid != curr_iccid:
        changes.append('SIM_CARD_CHANGED')
    if prev_op and prev_op != curr_op:
        changes.append('OPERATOR_CHANGED')
    if prev_iccid == 'UNKNOWN' and curr_iccid != 'UNKNOWN':
        changes.append('SIM_DETECTED')
    if not prev_iccid and curr_iccid == 'UNKNOWN':
        changes.append('SIM_REMOVED')
        if ALERT_ON_CHANGE == 'true' && [ -n \"\$TELEGRAM_BOT_TOKEN\" ]; then
            telegram_alert '⚠️ <b>SIM Removed</b>\nHost: $HOST\nTime: $TIMESTAMP'
        fi

probe['_changes'] = changes
print(json.dumps(probe, indent=2))
" 2>/dev/null || echo "$PROBE_JSON")

# ── Output & Persist ─────────────────────────────────────────────────────────

LOG_FILE="$LOG_DIR/${TIMESTAMP_FILE}.log"
echo "$FINAL_JSON" >> "$LOG_FILE"

# Pretty human-readable output
echo "═══════════════════════════════════════"
echo "  📡 SIM Probe — $TIMESTAMP"
echo "  Platform: $PLATFORM | Host: $HOST"
echo "═══════════════════════════════════════"

python3 -c "
import sys, json
d = json.loads(open('$LOG_FILE').read().strip().split('\n')[-1])
sim = d.get('sim',{})
wifi = d.get('wifi',{})
changes = d.get('_changes',[])

print()
print('  📶  CARRIER / NETWORK')
print(f'    Operator    : {sim.get(\"operator_name\",\"N/A\")} ({sim.get(\"operator_numeric\",\"\")})')
print(f'    Network Type: {sim.get(\"network_type\",\"N/A\")}')
print(f'    Country     : {sim.get(\"country\",\"N/A\")}')
print()
print('  📱  SIM CARD')
print(f'    ICCID       : {sim.get(\"iccid\",\"N/A\")}')
print(f'    Signal      : {sim.get(\"signal_strength\",\"N/A\")}')
print(f'    Call State  : {sim.get(\"call_state\",\"N/A\")}')
print(f'    Data Enabled: {sim.get(\"data_enabled\",\"N/A\")}')
print()
print('  📻  WI-FI')
if wifi.get('connected'):
    print(f'    SSID        : {wifi.get(\"ssid\",\"N/A\")}')
    print(f'    RSSI        : {wifi.get(\"rssi\",\"N/A\")} dBm')
    print(f'    Link Speed  : {wifi.get(\"link_speed\",\"N/A\")} Mbps')
else:
    print('    Wi-Fi       : Not connected')
print()
if changes:
    print('  ⚠️  CHANGES DETECTED:')
    for c in changes:
        print(f'    • {c}')
else:
    print('  ✅  No changes since last probe')
print()
" 2>/dev/null

# Cleanup old archives
log_rotate

# Save current state
echo "$FINAL_JSON" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(json.dumps(d))" > "$LAST_STATE_FILE"

# ── Telegram Alert on changes ─────────────────────────────────────────────────
if [ "$ALERT_ON_CHANGE" = "true" ] && [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
  CHANGES=$(echo "$FINAL_JSON" | python3 -c "import sys,json; print(','.join(json.load(sys.stdin).get('_changes',[])))" 2>/dev/null)
  if [ -n "$CHANGES" ]; then
    SIM_OP=$(echo "$FINAL_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin).get('sim',{}).get('operator_name','?'))" 2>/dev/null)
    SIM_ICCID=$(echo "$FINAL_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin).get('sim',{}).get('iccid','?'))" 2>/dev/null)
    MSG="📡 <b>SIM Change Detected</b>%0A%0A🆔 Changes: <code>${CHANGES}</code>%0A🏠 Host: <code>${HOST}</code>%0A🏳️ Operator: ${SIM_OP}%0A🔢 ICCID: <code>${SIM_ICCID}</code>%0A⏰ ${TIMESTAMP}"
    curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
      -d "chat_id=${TELEGRAM_CHAT_ID}" \
      -d "text=${MSG}" \
      -d "parse_mode=HTML" \
      --max-time 10 > /dev/null 2>&1 || true
  fi
fi

exit 0
