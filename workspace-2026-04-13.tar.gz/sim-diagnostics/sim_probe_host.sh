#!/bin/bash
# sim_probe_host.sh — Linux host SIM/network probe
# Queries the Android phone via ADB when available.
# Falls back to local ModemManager if modem present.
#
# Run via cron: bash /root/.openclaw/workspace/sim-diagnostics/sim_probe_host.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
HOST=$(hostname)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S %z')
TIMESTAMP_FILE=$(date '+%Y-%m-%d_%H')
ARCHIVED="$LOG_DIR/archived"
ARCHIVE_DAYS=14

mkdir -p "$LOG_DIR" "$ARCHIVED"

# Load config (optional)
CONFIG_FILE="$SCRIPT_DIR/sim_config.sh"
[ -f "$CONFIG_FILE" ] && source "$CONFIG_FILE"

TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-}"
ALERT_ON_CHANGE="${ALERT_ON_CHANGE:-true}"
LAST_STATE_FILE="$SCRIPT_DIR/.last_state_host.json"

# ── Helpers ───────────────────────────────────────────────────────────────────
log_rotate() {
  find "$LOG_DIR" -maxdepth 1 -name "*.log" -mtime +"$ARCHIVE_DAYS" -exec mv -t "$ARCHIVED" {} + 2>/dev/null || true
}

get_prev_state() { [ -f "$LAST_STATE_FILE" ] && cat "$LAST_STATE_FILE" || echo "{}"; }

telegram_alert() {
  local msg="$1"
  [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ] && return 0
  curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d "chat_id=${TELEGRAM_CHAT_ID}" \
    -d "text=${msg}" \
    -d "parse_mode=HTML" \
    --max-time 10 > /dev/null 2>&1 || true
}

# ── ADB Probes (phone) ─────────────────────────────────────────────────────────
has_adb_device() {
  adb devices 2>/dev/null | grep -v "List of devices" | grep -v "^$" | grep -v "offline" | grep -q "device$"
}

probe_via_adb() {
  # Check ADB connection
  if ! has_adb_device; then
    echo "ADB_NO_DEVICE"
    return 1
  fi

  local sim_status wifi_status network_status telephony_info

  sim_status=$(adb shell "termux-sim-status" 2>/dev/null) || sim_status="{}"
  wifi_status=$(adb shell "termux-wifi-connectioninfo" 2>/dev/null) || wifi_status="{}"
  network_status=$(adb shell "termux-network-information" 2>/dev/null) || network_status="{}"
  telephony_info=$(adb shell "termux-telephony-deviceinfo" 2>/dev/null) || telephony_info="{}"

  # Cell location
  local cell_info=""
  cell_info=$(adb shell "dumpsys telephony.registry" 2>/dev/null | grep -E "mCellLocation|cellLocation|phoneType|networkType|operator" | head -30) || cell_info=""

  # Airplane mode
  local airplane_mode=""
  airplane_mode=$(adb shell "getprop ro.airplane.mode" 2>/dev/null) || airplane_mode=""

  # Battery
  local battery=""
  battery=$(adb shell "dumpsys battery" 2>/dev/null | grep -E "level|status|health| plugged" | head -10) || battery=""

  # Build JSON
  python3 -c "
import sys, json, subprocess

def safe_get(d, *keys, default=''):
    for k in keys:
        if isinstance(d, dict):
            d = d.get(k, default)
        else:
            return default
    return d if d else default

try:
    sim = json.loads('''$sim_status''')
except:
    sim = {}

try:
    wifi = json.loads('''$wifi_status''')
except:
    wifi = {}

try:
    tel = json.loads('''$telephony_info''')
except:
    tel = {}

batt = {}
for line in '''$battery'''.strip().split('\n'):
    if ':' in line:
        k, v = line.split(':', 1)
        batt[k.strip().lower().replace(' ', '_')] = v.strip()

print(json.dumps({
    'probe': 'adb',
    'host': '''$HOST''',
    'phone_host': 'android',
    'timestamp': '''$TIMESTAMP''',
    'sim': {
        'iccid': safe_get(sim, 'iccid'),
        'operator': safe_get(sim, 'operator'),
        'operator_name': safe_get(sim, 'sim_operator_name'),
        'operator_numeric': safe_get(sim, 'sim_operator_numeric'),
        'country': safe_get(sim, 'sim_country'),
        'network_type': safe_get(sim, 'network_type'),
        'signal_strength': safe_get(sim, 'signal_strength'),
        'call_state': safe_get(sim, 'call_state'),
    },
    'wifi': {
        'connected': bool(wifi.get('ssid')),
        'ssid': wifi.get('ssid',''),
        'rssi': wifi.get('rssi',''),
        'link_speed': wifi.get('link_speed',''),
    },
    'telephony': {
        'device_id': tel.get('device_id',''),
        'network_type': tel.get('network_type_name',''),
        'data_enabled': tel.get('data_enabled',''),
    },
    'basestation_dump': ''' + str('''$cell_info''') + ''',
    'battery': batt,
    'airplane_mode': ''' + str('''$airplane_mode''').strip() + ''',
}, indent=2))
"
}

# ── ModemManager fallback ─────────────────────────────────────────────────────
probe_mmcli() {
  python3 << 'PYEOF'
import subprocess, json, sys

try:
    result = subprocess.run(['mmcli', '-m', 'any', '-J'], capture_output=True, text=True, timeout=15)
    if result.returncode != 0:
        sys.stdout.write('{"probe": "mmcli", "error": "no_modem"}')
        sys.exit(0)
    d = json.loads(result.stdout)
    m = d.get('modem', {})
    sim = m.get('sim', {})
    bearers = m.get('bearers', [])
    bearer = bearers[0] if bearers else {}
    props = bearer.get('properties', {}) if bearer else {}
    at_list = m.get('access-technologies', [])
    at_str = at_list[0].get('value', 'N/A') if at_list else 'N/A'
    sys.stdout.write(json.dumps({
        'probe': 'mmcli',
        'host': 'ahie',
        'timestamp': '',
        'sim': {
            'operator_name': m.get('operator-name', ''),
            'operator_code': m.get('operator-code', ''),
            'signal_quality': m.get('signal-quality', {}).get('value', ''),
            'access_technologies': at_str,
            'sim_identifier': sim.get('sim-identifier', ''),
            'sim_operator_name': sim.get('sim-operator-name', ''),
            'bearer_apn': props.get('apn', ''),
        }
    }, indent=2))
except Exception as e:
    sys.stdout.write(json.dumps({'probe': 'mmcli', 'error': str(e)}))
PYEOF
}

# ── Detect platform ───────────────────────────────────────────────────────────
probe() {
  if has_adb_device; then
    probe_via_adb
  else
    probe_mmcli
  fi
}

PROBE_OUT=$(probe)

# Handle "no adb device" gracefully
if [ "$PROBE_OUT" = "ADB_NO_DEVICE" ]; then
  PROBE_OUT=$(python3 -c "
import json, datetime
print(json.dumps({
    'probe': 'none',
    'host': '''$HOST''',
    'timestamp': '''$TIMESTAMP''',
    'status': 'no_modem_no_adb_phone',
    'message': 'No modem detected and no Android device connected via ADB. Run sim_probe.sh on the phone directly or connect via ADB.'
}, indent=2))
" 2>/dev/null)
fi

# ── Detect changes ─────────────────────────────────────────────────────────────
python3 -c "
import sys, json

curr = json.loads('''$PROBE_OUT''')
prev = json.loads('''$(get_prev_state)''')

changes = []
if prev:
    prev_iccid = prev.get('sim', {}).get('iccid', '') or prev.get('sim', {}).get('sim_identifier', '')
    curr_iccid = curr.get('sim', {}).get('iccid', '') or curr.get('sim', {}).get('sim_identifier', '')
    prev_op = prev.get('sim', {}).get('operator_name', '') or prev.get('sim', {}).get('operator', '')
    curr_op = curr.get('sim', {}).get('operator_name', '') or curr.get('sim', {}).get('operator', '')

    if prev_iccid and prev_iccid != curr_iccid:
        changes.append('SIM_CARD_CHANGED')
    if prev_op and prev_op != curr_op:
        changes.append('OPERATOR_CHANGED')

curr['_changes'] = changes
print(json.dumps(curr, indent=2))
" > "$LAST_STATE_FILE.tmp" 2>/dev/null && mv "$LAST_STATE_FILE.tmp" "$LAST_STATE_FILE"

FINAL=$(cat "$LAST_STATE_FILE")

# ── Log ───────────────────────────────────────────────────────────────────────
LOG_FILE="$LOG_DIR/${TIMESTAMP_FILE}.log"
echo "$FINAL" >> "$LOG_FILE"

# ── Pretty output ─────────────────────────────────────────────────────────────
echo "═══════════════════════════════════════"
echo "  📡 SIM Probe (Host) — $TIMESTAMP"
echo "  Host: $HOST"
echo "═══════════════════════════════════════"

python3 -c "
import sys, json

d = json.loads(open('$LAST_STATE_FILE').read())
probe_type = d.get('probe', '?')
sim = d.get('sim', {})
wifi = d.get('wifi', {})
tel = d.get('telephony', {})
batt = d.get('battery', {})
changes = d.get('_changes', [])

print()
print(f'  🔧  Probe Type: {probe_type.upper()}')
print()
print('  📶  CARRIER / NETWORK')
print(f'    Operator    : {sim.get(\"operator_name\", sim.get(\"operator\", \"N/A\"))}')
print(f'    Operator Code: {sim.get(\"operator_code\", sim.get(\"operator_numeric\", \"N/A\"))}')
print(f'    Access Tech : {sim.get(\"access_technologies\", sim.get(\"network_type\", \"N/A\"))}')
print(f'    Signal Quality: {sim.get(\"signal_quality\", sim.get(\"signal_strength\", \"N/A\"))}')
print()
print('  📱  SIM CARD')
print(f'    ICCID/ID    : {sim.get(\"iccid\", sim.get(\"sim_identifier\", \"N/A\"))}')
print(f'    APN         : {sim.get(\"bearer_apn\", \"N/A\")}')
print()
print('  📻  WI-FI')
if wifi.get('connected'):
    print(f'    SSID        : {wifi.get(\"ssid\", \"N/A\")}')
    print(f'    RSSI        : {wifi.get(\"rssi\", \"N/A\")} dBm')
    print(f'    Link Speed  : {wifi.get(\"link_speed\", \"N/A\")} Mbps')
else:
    print('    Wi-Fi       : Not connected')
print()
if tel:
    print('  📞  TELEPHONY')
    print(f'    Device ID   : {tel.get(\"device_id\", \"N/A\")}')
    print(f'    Network Type: {tel.get(\"network_type\", \"N/A\")}')
    print(f'    Data Enabled: {tel.get(\"data_enabled\", \"N/A\")}')
print()
if batt:
    print('  🔋  BATTERY')
    for k, v in batt.items():
        print(f'    {k:14s}: {v}')
    print()
if changes:
    print('  ⚠️  CHANGES DETECTED:')
    for c in changes:
        print(f'    • {c}')
else:
    print('  ✅  No changes since last probe')
print()
" 2>/dev/null

# ── Alert on changes ──────────────────────────────────────────────────────────
if [ "$ALERT_ON_CHANGE" = "true" ] && [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
  CHANGES=$(echo "$FINAL" | python3 -c "import sys,json; print(','.join(json.load(sys.stdin).get('_changes',[])))" 2>/dev/null)
  if [ -n "$CHANGES" ]; then
    SIM_OP=$(echo "$FINAL" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sim',{}).get('operator_name', d.get('sim',{}).get('operator','?')))" 2>/dev/null)
    SIM_ICCID=$(echo "$FINAL" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sim',{}).get('iccid', d.get('sim',{}).get('sim_identifier','?')))" 2>/dev/null)
    PROBE_TYPE=$(echo "$FINAL" | python3 -c "import sys,json; print(json.load(sys.stdin).get('probe','?'))" 2>/dev/null)
    MSG="📡 <b>SIM Change — Host Probe</b>%0A%0A🆔 Changes: <code>${CHANGES}</code>%0A🏠 Host: <code>${HOST}</code>%0A🔧 Probe: <code>${PROBE_TYPE}</code>%0A🏳️ Operator: ${SIM_OP}%0A🔢 ICCID: <code>${SIM_ICCID}</code>%0A⏰ ${TIMESTAMP}"
    telegram_alert "$MSG"
  fi
fi

# Archive old logs
log_rotate

exit 0
