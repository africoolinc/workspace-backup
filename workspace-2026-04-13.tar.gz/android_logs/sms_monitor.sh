#!/bin/bash
# Android SMS Monitor - checks for new messages and logs for sentiment analysis
# Run via cron every 5 minutes

LOG_DIR="/root/.openclaw/workspace/android_logs"
SENTIMENT_LOG="$LOG_DIR/sentiment_$(date +%Y-%m-%d).jsonl"
LAST_ID_FILE="$LOG_DIR/.last_sms_id"

mkdir -p "$LOG_DIR"

LAST_ID=$(cat "$LAST_ID_FILE" 2>/dev/null || echo "0")
NEW_HIGHEST=0

# Query SMS and process each Row line
adb shell 'content query --uri content://sms/inbox --projection _id,address,body,date --sort "date DESC"' 2>/dev/null | while IFS= read -r line; do
    # Check if line starts with "Row:" prefix
    if [[ "${line:0:4}" != "Row:" ]]; then
        continue
    fi
    
    # Extract _id value - find _id= and extract until next comma
    id_part="${line#*_id=}"
    msg_id="${id_part%%,*}"
    
    # Check if valid number
    if [[ ! "$msg_id" =~ ^[0-9]+$ ]]; then
        continue
    fi
    
    if [[ "$msg_id" -le "$LAST_ID" ]]; then
        continue
    fi
    
    if [[ "$msg_id" -gt "$NEW_HIGHEST" ]]; then
        NEW_HIGHEST="$msg_id"
    fi
    
    # Extract address (after "address=" until ", body=")
    addr_part="${line#*address=}"
    address="${addr_part%%, body=*}"
    
    # Extract body (after "body=" until END of line - use a unique delimiter)
    body_part="${line#*body=}"
    # Body goes until a comma followed by space+date= (end of body field)
    body=$(echo "$body_part" | sed 's/, date=.*$//')
    
    # Extract date (after "date=" until end of line)
    date=$(echo "$line" | sed 's/.*, date=//')
    
    ts=$(date -d @$((10#$date / 1000)) +"%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "$date")
    
    # Simple sentiment scoring
    body_lower=$(echo "$body" | tr '[:upper:]' '[:lower:]')
    sentiment="neutral"
    sentiment_score=0
    
    if echo "$body_lower" | grep -qE "(thanks|thank you|great|good|awesome|please|welcome|love|happy|congrats|yes|ok|sure)"; then
        sentiment="positive"
        sentiment_score=0.6
    elif echo "$body_lower" | grep -qE "(no|not|don't|can't|won't|never|sorry|problem|issue|wrong|bad|unfortunately|missed|failed|hate)"; then
        sentiment="negative"
        sentiment_score=-0.5
    elif echo "$body_lower" | grep -qE "(urgent|asap|emergency|important|immediately|now|help)"; then
        sentiment="urgent"
        sentiment_score=0.8
    fi
    
    # Escape JSON special characters using Python
    body_escaped=$(echo "$body" | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read()))' 2>/dev/null | tr -d '"')
    address_escaped=$(echo "$address" | sed 's/\\/\\\\/g; s/"/\\"/g')
    
    echo "{\"ts\":\"$ts\",\"msg_id\":$msg_id,\"address\":\"$address_escaped\",\"body\":$body_escaped,\"sentiment\":\"$sentiment\",\"sentiment_score\":$sentiment_score,\"logged_at\":\"$(date -Iseconds)\"}" >> "$SENTIMENT_LOG"
done

if [[ "$NEW_HIGHEST" -gt 0 ]]; then
    echo "$NEW_HIGHEST" > "$LAST_ID_FILE"
fi

echo "$(date): SMS check completed. Last processed: $(cat $LAST_ID_FILE)" >> "$LOG_DIR/monitor.log"