#!/usr/bin/env bash
# Oracle Contact Intelligence — Call Log + SMS + Sentiment Extractor
# Runs on HOST via ADB, saves structured contact data to workspace
# No termux needed — works fully offline via dumpsys + logcat

set -uo pipefail

ORACLE_DATA="/root/.openclaw/workspace/android_logs"
CONTACTS_FILE="${ORACLE_DATA}/contacts_sentiment_$(date +%Y-%m-%d).jsonl"
CALL_LOG_FILE="${ORACLE_DATA}/call_log_$(date +%Y-%m-%d).jsonl"
LAST_CONTACTS="${ORACLE_DATA}/.last_contacts_hash"
TMP_DIR="/tmp/oracle_contacts_$$"
mkdir -p "${TMP_DIR}"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

# ── 1. Extract call events from telecom dumpsys ───────────────────────────────
extract_calls() {
    adb shell "dumpsys telecom 2>/dev/null" > "${TMP_DIR}/telecom.dump"
    
    # Parse call events from CallAudioModeStateMachine History
    # Format: "2026-04-08T14:56:36.178103 - Enter SIM_CALL"
    grep -E "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}" "${TMP_DIR}/telecom.dump" | \
    grep -E "SIM_CALL|RINGING|UNFOCUSED|MODE_IN_CALL|MODE_NORMAL|MODE_RINGING" | \
    sed 's/  */ /g' > "${TMP_DIR}/call_events.txt"
    
    # Count call types
    local missed=$(grep -c "MISSED)" "${TMP_DIR}/telecom.dump" 2>/dev/null || echo 0)
    local remote=$(grep -c "REMOTE).*NORMAL" "${TMP_DIR}/telecom.dump" 2>/dev/null || echo 0)
    local local_disc=$(grep -c "LOCAL)" "${TMP_DIR}/telecom.dump" 2>/dev/null || echo 0)
    
    # Parse into structured call records
    local call_count=0
    local prev_time="" prev_state="" call_start=""
    
    while IFS= read -r line; do
        local ts state
        ts=$(echo "${line}" | awk '{print $1"T" $2}')
        state=$(echo "${line}" | sed 's/.* - //')
        
        if [[ "${state}" == "Enter SIM_CALL" ]]; then
            call_start="${ts}"
        elif [[ "${state}" == "Enter UNFOCUSED" || "${state}" == "Mode MODE_NORMAL" ]] && [[ -n "${call_start}" ]]; then
            local call_end="${ts}"
            local duration=""
            if [[ -n "${call_start}" && -n "${call_end}" ]]; then
                # Calculate duration in seconds
                local start_sec end_sec
                start_sec=$(date -d "${call_start}" +%s 2>/dev/null || echo 0)
                end_sec=$(date -d "${call_end}" +%s 2>/dev/null || echo 0)
                duration=$((end_sec - start_sec))
            fi
            
            # Determine call type from surrounding context
            local call_type="outgoing"
            if grep -B2 -A2 "${call_start}" "${TMP_DIR}/telecom.dump" 2>/dev/null | grep -q "MISSED)"; then
                call_type="missed"
            elif [[ "${state}" == "Mode MODE_NORMAL" && "${call_start}" == *"RINGING"* ]]; then
                call_type="incoming"
            fi
            
            cat >> "${CALL_LOG_FILE}" << EOF
{"ts":"${call_start}","call_type":"${call_type}","duration_sec":${duration:-0},"ended":"${call_end}"}
EOF
            call_count=$((call_count + 1))
            call_start=""
        fi
    done < "${TMP_DIR}/call_events.txt"
    
    echo "${call_count} calls extracted | missed=${missed} | answered=${remote} | local=${local_disc}"
}

# ── 2. Extract SMS from existing sentiment file ───────────────────────────────
extract_sms() {
    # Use the already-extracted sentiment file
    local sentiment_file="${ORACLE_DATA}/sentiment_$(date +%Y-%m-%d).jsonl"
    if [[ -f "${sentiment_file}" ]]; then
        local count=$(wc -l < "${sentiment_file}")
        echo "Using ${count} SMS entries from ${sentiment_file}"
        cp "${sentiment_file}" "${TMP_DIR}/sms_entries.jsonl"
    else
        echo "No sentiment file found for today"
    fi
}

# ── 3. Extract unique contacts from SMS ──────────────────────────────────────
extract_contacts() {
    local contacts={}
    
    if [[ -f "${TMP_DIR}/sms_entries.jsonl" ]]; then
        # Extract unique addresses from SMS
        grep -oE '"address":"[^"]*"' "${TMP_DIR}/sms_entries.jsonl" | \
            sed 's/"address":"//;s/"//g' | \
            sort -u | \
            while read -r addr; do
                # Get all messages from this address
                local msg_count=$(grep "\"${addr}\"" "${TMP_DIR}/sms_entries.jsonl" | wc -l)
                local last_msg=$(grep "\"${addr}\"" "${TMP_DIR}/sms_entries.jsonl" | tail -1)
                local last_ts=$(echo "${last_msg}" | grep -oE '"ts":"[^"]*"' | sed 's/"ts":"//;s/"//' | head -1)
                local sentiment=$(echo "${last_msg}" | grep -oE '"sentiment":"[^"]*"' | sed 's/"sentiment":"//;s/"//')
                
                # Label contact type
                local label="unknown"
                if [[ "${addr}" == *"MPESA"* ]] || [[ "${addr}" == *"KPLC"* ]]; then
                    label="financial"
                elif [[ "${addr}" == *"SAFARICOM"* ]]; then
                    label="network"
                elif [[ "${addr}" =~ ^\+254 ]] || [[ "${addr}" =~ ^0[0-9]{9} ]]; then
                    label="person"
                fi
                
                cat >> "${CONTACTS_FILE}" << EOF
{"address":"${addr}","label":"${label}","msg_count":${msg_count},"last_contact":"${last_ts}","last_sentiment":"${sentiment:-neutral}"}
EOF
            done
    fi
    
    local count=$(wc -l < "${CONTACTS_FILE}" 2>/dev/null || echo 0)
    echo "${count} contacts extracted"
}

# ── 4. Build contact intelligence summary ────────────────────────────────────
build_summary() {
    local summary_file="${ORACLE_DATA}/contacts_summary_$(date +%Y-%m-%d).json"
    
    local total_contacts=$(wc -l < "${CONTACTS_FILE}" 2>/dev/null || echo 0)
    local total_calls=$(wc -l < "${CALL_LOG_FILE}" 2>/dev/null || echo 0)
    local missed_calls=$(grep -c "missed" "${CALL_LOG_FILE}" 2>/dev/null || echo 0)
    local financial_msgs=$(grep -c "financial" "${CONTACTS_FILE}" 2>/dev/null || echo 0)
    local person_msgs=$(grep -c "person" "${CONTACTS_FILE}" 2>/dev/null || echo 0)
    
    # Get today's SMS count
    local today_sms=$(wc -l < "${TMP_DIR}/sms_entries.jsonl" 2>/dev/null || echo 0)
    
    cat > "${summary_file}" << EOF
{
  "generated": "$(date -Iseconds)",
  "period": "$(date +%Y-%m-%d)",
  "total_contacts": ${total_contacts},
  "total_calls_today": ${total_calls},
  "missed_calls_today": ${missed_calls},
  "sms_today": ${today_sms},
  "financial_contacts": ${financial_msgs},
  "person_contacts": ${person_msgs}
}
EOF
    echo "Summary saved: ${summary_file}"
}

# ── Main ──────────────────────────────────────────────────────────────────
log "=== Oracle Contact Intelligence started ==="

extract_calls
extract_sms
extract_contacts
build_summary

# Cleanup
rm -rf "${TMP_DIR}"

log "=== Done ==="
log "Call log: ${CALL_LOG_FILE}"
log "Contacts: ${CONTACTS_FILE}"
